<?php
    require_once("include/session.php");

    if(isset($_POST['delete_error'])){
        $ges->deleteError($_POST['error_id']);
    }elseif(isset($_POST['generate_excel'])){
        $ges->generateExcelReport();
    }

    if(isset($_GET['validation_id'])){
        if(isset($_POST['fix_error'])){
            $ges->changeErrorStatus($_POST['error_id'], 1);
        }elseif(isset($_POST['edit-error'])){
            $ges->updateError();
        }

        $validation_id = $_GET['validation_id'];
        $errors = $ges->getPartnumErrors($validation_id);
        $validation = $ges->getValidationDetails($validation_id);
        $user = $ges->getValidator($validation_id);
    }else{
        $errors = $ges->getAllErrors();
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>GES Validation</title>

        <!-- Styles -->
        <link href="public/css/bootstrap.min.css" rel="stylesheet">
        <link href="public/css/dataTables.bootstrap.min.css" rel="stylesheet" >
        <link href="public/css/ges.css" rel="stylesheet" >
        <link href="public/css/font-awesome.css" rel="stylesheet" >

        <!-- JavaScripts -->
        <script src="public/js/jquery.min.js"></script>
        <script src="public/js/jquery.dataTables.js"></script>
        <style>
            .error-desc{
                font-size: 12px;
            }
            .table > tbody > tr > td {
                 vertical-align: middle;
            }
        </style>

    </head>
    <body>

        <?php require_once("layouts/navbar.php"); ?>

        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-2">
                    <?php 
                        if(isset($validation_id)){

                            require_once("layouts/errors/validation_errors.php");

                        }else{

                            require_once("layouts/errors/all_errors.php");

                        }
                    ?>
                </div>
            </div>
        </div>

        <script src="public/js/bootstrap.min.js"></script>
        <script src="public/js/dataTables.bootstrap.min.js"></script>
        <script>
            $(document).ready( function () {
                $('#all-errors-table').DataTable({
                    "lengthMenu": [[-1, 20, 50],['All', 20, 50]]
                });
            });
        </script>
    </body>
</html>