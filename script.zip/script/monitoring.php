<?php
    require_once("include/session.php");

    if(isset($_POST['add_on_queue'])){
            $ges->addValidation();
    }elseif(isset($_POST['generate_excel'])){
        $ges->generateExcelReport();
    }

    $users_stats = $ges->getUsersStats();
    $daily_stats = $ges->getDailyStats();
    $weekly_stats = $ges->getStats(date('Y-m-d', strtotime('-6 days')),date('Y-m-d'));
    $monthly_stats = $ges->getStats(date('Y-m')."-01",date('Y-m-d'));
    $error_count = $ges->getErrorCount();
?>      
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>GES Validation</title>

        <!-- Styles -->
        <link href="public/css/bootstrap.min.css" rel="stylesheet">
        <link href="public/css/dataTables.bootstrap.min.css" rel="stylesheet" >
        <link href="public/css/ges.css" rel="stylesheet" >

        <!-- JavaScripts -->
        <script src="public/js/jquery.min.js"></script>
        <script src="public/js/jquery.dataTables.js"></script>
        <script src="public/js/Chart.js"></script>

        <style>
            .panel-heading h3 {
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                line-height: normal;
                width: 75%;
                padding-top: 8px;
            }
            .no-top-border {
                border-top: none;
            }
            .text-dates {
                font-size: 12px;
            }
            .text-small {
                font-size: 11px;
            }
        </style>
    </head>
    <body>
        
        <?php require_once("layouts/navbar.php"); ?>

        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-2">
                    <h4 class="page-header">GES Monitoring</h4>
                        <?php
                            if(isset($_SESSION['USER'])){
                                require_once("add_on_queue.php");
                            }
                        ?>
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="row">
                                <?php foreach($users_stats as $user){

                                ?>

                                    <div class="col-md-4">
                                        <div class="panel panel-default">
                                            <div class="panel-body">
                                                <h4> <b> <?php echo $user['NAME'] ?> </b> </h4> 
                                                <table class="table">
                                                    <thead>
                                                        <tr>
                                                            <th>
                                                                All Validations
                                                            </th>
                                                            <td align="right">
                                                                <a <?php echo "href='validations.php?USER_ID=".$user['ID']."'"; ?> ><?php echo $user['ONQUEUE'] + $user['VALIDATED']; ?></a>
                                                            </td>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>
                                                                Finished
                                                            </td>
                                                            <td align="right">
                                                                <a <?php echo "href='validations.php?USER_ID=".$user['ID']."&sort=1'"; ?>><?php echo $user['VALIDATED'] ?></a>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>
                                                                On Queue
                                                            </td>
                                                            <td align="right">
                                                                <a <?php echo "href='validations.php?USER_ID=".$user['ID']."&sort=0'"; ?> ><?php echo $user['ONQUEUE'] ?></a>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>

                                <?php 

                                    }

                                ?>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h3 class="panel-title pull-left">
                                Overview
                            </h3>
                            <div class="clearfix"></div>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="panel-body">
                                    <ul class="nav nav-tabs">
                                        <li class="active"><a data-toggle="tab" href="#overall">Overall</a></li>
                                        <li><a data-toggle="tab" href="#monthly">Monthly</a></li>
                                        <li><a data-toggle="tab" href="#weekly">Weekly</a></li>
                                    </ul>

                                    <div class="tab-content">
                                        <div id="overall" class="tab-pane fade in active">
                                            <div class="panel panel-default no-top-border">
                                                <div class="panel-body">
                                                    <div class="page-header"> <b> Overall Stats </b> </div>
                                                    <div class="col-md-8">
                                                        <table class="table table-hover table-bordered" width="100%">
                                                            <thead>    
                                                                <tr>
                                                                    <th>Validator</th>
                                                                    <th>Without errors</th>
                                                                    <th>With errors</th>
                                                                    <th>Total Validations</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php
                                                                    $overall_onqueue = 0;
                                                                    $overall_finished = 0;
                                                                    foreach($users_stats as $user){

                                                                ?>


                                                                <tr>
                                                                    <td><?php echo $user['NAME']; ?></td>
                                                                    <td align="right"><?php echo $user['NO_ERRORS']; ?></td>
                                                                    <td align="right"><?php echo $user['HAS_ERRORS']; ?></td>
                                                                    <td align="right"><?php echo $user['VALIDATED']; ?></td>
                                                                </tr>

                                                                <?php
                                                                        $overall_onqueue += $user['ONQUEUE'];
                                                                        $overall_finished += $user['VALIDATED'];
                                                                    }

                                                                ?>
                                                                <tr>
                                                                    <td> <b> Overall Total </b> </td>
                                                                    <td></td>
                                                                    <td></td>
                                                                    <td align="right"><?php echo $overall_finished; ?></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="row">
                                                            <div class="panel panel-default">
                                                                <div class="panel-body">
                                                                    <table class="table">
                                                                        <thead>
                                                                            <tr>
                                                                                <td>
                                                                                    Finished Validations
                                                                                </td>
                                                                                <td align="right">
                                                                                    <a href="validations.php?sort=1"><?php echo $overall_finished; ?></a>
                                                                                </td>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            <tr>
                                                                                <td>
                                                                                    On Queue Validations
                                                                                </td>
                                                                                <td align="right">
                                                                                    <a href="validations.php?sort=0"><?php echo $overall_onqueue; ?></a>
                                                                                </td>
                                                                            </tr>
                                                                            <tr>
                                                                                <td>
                                                                                    Errors Found
                                                                                </td>
                                                                                <td align="right">
                                                                                    <a href="errors.php"><?php echo $error_count['OVERALL']; ?></a>
                                                                                </td>
                                                                            </tr>
                                                                        </tbody>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <table class="table-condensed">
                                                                <tr>
                                                                    <td>
                                                                        <a href="create_report.php" target="_blank" class="btn btn-sm btn-primary">Generate Report</a>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td>
                                                                        <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                                                                            <input type="hidden" name="generate_excel" value="1">
                                                                        
                                                                            <button type="submit" class="btn btn-success btn-sm">
                                                                            Generate Spreadsheet
                                                                            </button>
                                                                        </form>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="monthly" class="tab-pane fade">
                                            <div class="panel panel-default no-top-border">
                                                <div class="panel-body">
                                                    <div class="page-header"> 
                                                        <b> Monthly Stats </b>
                                                        <div class="text-dates"> 
                                                            <?php echo date('m')."/01/".date('Y')." - ".date('m/d/Y'); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <table class="table table-hover table-bordered" width="100%">
                                                            <thead>    
                                                                <tr>
                                                                    <th>Validator</th>
                                                                    <th>Without errors</th>
                                                                    <th>With errors</th>
                                                                    <th>Total Validations</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php
                                                                    $monthly_total = 0;
                                                                    foreach($monthly_stats as $values){

                                                                ?>


                                                                <tr>
                                                                    <td><?php echo $values['NAME']; ?></td>
                                                                    <td align="right"><?php echo $values['NO_ERRORS']; ?></td>
                                                                    <td align="right"><?php echo $values['HAS_ERRORS']; ?></td>
                                                                    <td align="right"><?php echo $values['VALIDATED']; ?></td>
                                                                </tr>

                                                                <?php
                                                                        $monthly_total += $values['VALIDATED'];
                                                                    }

                                                                ?>
                                                                <tr>
                                                                    <td> <b> Overall Total </b> </td>
                                                                    <td></td>
                                                                    <td></td>
                                                                    <td align="right"><?php echo $monthly_total; ?></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="panel panel-default">
                                                            <div class="panel-body">
                                                                <table class="table">
                                                                    <thead>
                                                                        <tr>
                                                                            <td>
                                                                                Finished Validations
                                                                            </td>
                                                                            <td align="right">
                                                                                <a <?php echo "href='validations.php?sort=1&date_start=".urlencode(date('m')."-01-".date('Y'))."'"; ?> ><?php echo $monthly_total; ?></a>
                                                                            </td>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td>
                                                                                Errors Found
                                                                            </td>
                                                                            <td align="right">
                                                                                <a <?php echo "href='errors.php?date_start=".urlencode(date('m')."-01-".date('Y'))."'"; ?> > <?php echo $error_count['MONTHLY']; ?> </a>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="weekly" class="tab-pane fade">
                                            <div class="panel panel-default no-top-border">
                                                <div class="panel-body">
                                                    <div class="page-header"> 
                                                        <b> Weekly Stats </b>
                                                        <div class="text-dates"> 
                                                            <?php echo date('m/d/Y', strtotime('-7 days'))." - ".date('m/d/Y'); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <table class="table table-hover table-bordered" width="100%">
                                                            <thead>    
                                                                <tr>
                                                                    <th>Validator</th>
                                                                    <th>Without errors</th>
                                                                    <th>With errors</th>
                                                                    <th>Total Validations</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php
                                                                    $weekly_total = 0;
                                                                    foreach($weekly_stats as $values){
                                                                ?>

                                                                <tr>
                                                                    <td><?php echo $values['NAME']; ?></td>
                                                                    <td align="right"><?php echo $values['NO_ERRORS']; ?></td>
                                                                    <td align="right"><?php echo $values['HAS_ERRORS']; ?></td>
                                                                    <td align="right"><?php echo $values['VALIDATED']; ?></td>
                                                                </tr>

                                                                <?php
                                                                        $weekly_total += $values['VALIDATED'];
                                                                    }
                                                                ?>
                                                                <tr>
                                                                    <td> <b> Overall Total </b> </td>
                                                                    <td></td>
                                                                    <td></td>
                                                                    <td align="right"><?php echo $weekly_total; ?></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="panel panel-default">
                                                            <div class="panel-body">
                                                                <table class="table">
                                                                    <thead>
                                                                        <tr>
                                                                            <td>
                                                                                Finished Validations
                                                                            </td>
                                                                            <td align="right">
                                                                                <a href="validations.php?sort=1"><?php echo $weekly_total; ?></a>
                                                                            </td>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        <tr>
                                                                            <td>
                                                                                Errors Found
                                                                            </td>
                                                                            <td align="right">
                                                                                <a href="errors.php"><?php echo $error_count['WEEKLY']; ?></a>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="panel panel-default">
                                        <div class="panel-body">
                                            <div class="page-header"> 
                                                <b> Daily Stats </b>
                                                <div class="text-dates"> 
                                                    <?php echo date('m/d/Y', strtotime('-6 days'))." - ".date('m/d/Y'); ?> 
                                                </div>
                                            </div>

                                            <?php 

                                                $days = Array();
                                                for($i=6;$i>=0;$i--){

                                                    $day = date('w', strtotime(date('Y-m-d', strtotime('-'.$i.' days'))));

                                                    switch($day){
                                                        case 0: array_push($days, "Sun");
                                                                break;
                                                        case 1: array_push($days, "Mon");
                                                                break;
                                                        case 2: array_push($days, "Tue");
                                                                break;
                                                        case 3: array_push($days, "Wed");
                                                                break;
                                                        case 4: array_push($days, "Thurs");
                                                                break;
                                                        case 5: array_push($days, "Fri");
                                                                break;
                                                        case 6: array_push($days, "Sat");
                                                                break;
                                                        default: array_push($days, "Unknown");
                                                    }
                                                }

                                            ?>
                                            <div class="col-md-12">
                                                <table class="table table-hover table-bordered daily-table" width="100%">
                                                    <thead>    
                                                        <tr>
                                                            <th>Validator</th>
                                                            <th><?php echo date('m-d', strtotime('-6 days'))." ".$days[0]; ?> </th>
                                                            <th><?php echo date('m-d', strtotime('-5 days'))." ".$days[1]; ?> </th>
                                                            <th><?php echo date('m-d', strtotime('-4 days'))." ".$days[2]; ?> </th>
                                                            <th><?php echo date('m-d', strtotime('-3 days'))." ".$days[3]; ?> </th>
                                                            <th><?php echo date('m-d', strtotime('-2 days'))." ".$days[4]; ?> </th>
                                                            <th><?php echo date('m-d', strtotime('-1 days'))." ".$days[5]; ?> </th>
                                                            <th><?php echo date('m-d')." ".$days[6].""; ?> </th>
                                                            <th>Total Validations</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                            $daily_total = 0;
                                                            foreach($daily_stats as $values){

                                                                ?>
                                                                    <tr>
                                                                        <td><?php echo $values['NAME']; ?></td>
                                                                        <td align="right"><?php echo $values['ONE']; ?></td>
                                                                        <td align="right"><?php echo $values['TWO']; ?></td>
                                                                        <td align="right"><?php echo $values['THREE']; ?></td>
                                                                        <td align="right"><?php echo $values['FOUR']; ?></td>
                                                                        <td align="right"><?php echo $values['FIVE']; ?></td>
                                                                        <td align="right"><?php echo $values['SIX']; ?></td>
                                                                        <td align="right"><?php echo $values['SEVEN']; ?></td>
                                                                        <td align="right"><?php echo $values['TOTAL']; ?></td>
                                                                    </tr>

                                                                <?php

                                                                $daily_total += $values['TOTAL'];
                                                            }

                                                        ?>
                                                        <tr>
                                                            <td> <b> Overall Total </b> </td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td></td>
                                                            <td align="right"><?php echo $daily_total; ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                
                                <?php

                                    $label_names = "";
                                    $bar_values = "";
                                    foreach($weekly_stats as $values){
                                        $label_names .= "'".$values['NAME']."',";
                                        $bar_values .= "'".$values['VALIDATED']."',";
                                    }
                                    $label_names = rtrim($label_names,", ");
                                    $bar_values = rtrim($bar_values,", ");

                                ?>

                            <div class="row">
                                <div class="col-md-12">
                                    <div class="panel panel-default">
                                        <div class="panel-body">
                                            <h4><b>GES Weekly Validation</b></h4>      
                                            <div class="panel-body">
                                                <div>
                                                    <canvas id="validationsChart"></canvas>
                                                    <br/>
                                                    <p class="text-muted text-small"> 
                                                        *validations from <?php echo date('m/d/Y', strtotime('-7 days'))." - ".date('m/d/Y'); ?>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <script>
                              var barChartData = {
                                    labels: [<?php echo $label_names; ?>],
                                    datasets: [{
                                        type: 'bar',
                                        label: 'Actual ',
                                        data: [<?php echo $bar_values; ?>],
                                        fill: false,
                                            backgroundColor: [
                                                'rgba(255, 99, 132, 0.2)',
                                                'rgba(54, 162, 235, 0.2)',
                                                'rgba(255, 206, 86, 0.2)',
                                                'rgba(75, 192, 192, 0.2)',
                                                'rgba(153, 102, 255, 0.2)',
                                                'rgba(153, 102, 255, 0.2)'
                                            ],
                                            borderColor: [
                                                'rgba(255,99,132,1)',
                                                'rgba(54, 162, 235, 1)',
                                                'rgba(255, 206, 86, 1)',
                                                'rgba(75, 192, 192, 1)',
                                                'rgba(153, 102, 255, 1)',
                                                'rgba(153, 102, 255, 1)'
                                            ],
                                            borderWidth: 1
                                    }, {
                                            type:'line',
                                            label: 'Target ',
                                            data: [96, 96, 96, 96, 96, 96, 96],
                                            fill: false,
                                            borderColor: '#EC932F',
                                            backgroundColor: '#EC932F',
                                            pointRadius: 0,
                                    } ]
                                };
                                
                                window.onload = function() {
                                    var ctx = document.getElementById("validationsChart").getContext("2d");

                                    window.myBar = new Chart(ctx, {
                                        type: 'bar',
                                        data: barChartData,
                                        options: {
                                            responsive: true,
                                            tooltips: {
                                                mode: 'label'
                                            },
                                            legend: {
                                                display: false
                                            },
                                            scales: {
                                                yAxes: [{
                                                    display: true,
                                                    ticks: {
                                                        suggestedMax: 100,
                                                        suggestedMin: 0,
                                                        beginAtZero: true
                                                    }
                                                }],
                                                xAxes: [{
                                                    gridLines: {
                                                        display:false
                                                    }
                                                }]
                                            }
                                        }
                                    });
                                };
                            </script>
                            <?php if(isset($_SESSION['USER'])){ ?>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="panel">
                                            <div class="panel-body">
                                                <a href="activity_log.php" class="btn btn-primary btn-md pull-right">Activity Log</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="public/js/bootstrap.min.js"></script>
        <script src="public/js/dataTables.bootstrap.min.js"></script>
    </body>
</html>