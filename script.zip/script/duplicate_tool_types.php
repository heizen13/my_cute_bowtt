<?php
    require_once("include/session.php");

    if(isset($_POST['PART_NUM']) && isset($_POST['RC_ID'])){
        $part_num = $_POST['PART_NUM'];
        $rc_id = $_POST['RC_ID'];

        $results = $ges->getDuplicateToolTypes($part_num, $rc_id);

    }elseif(isset($_GET['PART_NUM']) && isset($_GET['RC_ID'])){
        $part_num = $_GET['PART_NUM'];
        $rc_id = intval($_GET['RC_ID']);

        $results = $ges->getDuplicateToolTypes($part_num, $rc_id);
    }
?>   

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>GES Validation</title>

        <!-- Styles -->
        <link href="public/css/bootstrap.min.css" rel="stylesheet">
        <link href="public/css/dataTables.bootstrap.min.css" rel="stylesheet" >
        <link href="public/css/ges.css" rel="stylesheet" >

        <!-- JavaScripts -->
        <script src="public/js/jquery.min.js"></script>
        <script src="public/js/jquery.dataTables.js"></script>
        <script src="public/js/ges.js"></script>
    </head>
    <body>

        <?php require_once("layouts/navbar.php"); ?>

        <div class="container">
            <div class="row">
                <h4 class="page-header">Duplicate Tool Type Search</h4>
                <div class="panel">
                    <div class="panel-body">
                        <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                            <div class="flex-container">
                                <div class="required-fields">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label"> Part Number </label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" name="PART_NUM" <?php if(isset($_POST['PART_NUM'])) echo "value='".$_POST['PART_NUM']."'"; ?> required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label"> RC ID </label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" name="RC_ID" <?php if(isset($_POST['RC_ID'])) echo "value='".$_POST['RC_ID']."'"; ?> required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-md-3 col-md-offset-3">
                                            <button type="submit" class="btn btn-primary">
                                                Search
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="optional-fields-panel">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-body">
                        <h4 class="page-header">Results</h4> 
                        <table class="table table-hover table-bordered table-results" id="new-table" width="100%">
                            <thead>    
                                <tr>
                                    <th>Part Number</th>
                                    <th>Seq No</th>
                                    <th>Setup No</th>
                                    <th>Operation Code</th>
                                    <th>Step Type Code</th>
                                    <th>Tool Type</th>
                                    <th>Tooling Part No</th>
                                    <th>Tool Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    if(isset($results) && count($results) > 0){
                                        foreach($results as $values){
                                            echo "<tr class='error-row'>";

                                            foreach($values as $value){
                                                echo "<td>".$value."</td>";
                                            }

                                            echo "</tr>";
                                        }
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <script src="public/js/bootstrap.min.js"></script>
        <script src="public/js/dataTables.bootstrap.min.js"></script>
    </body>
</html>