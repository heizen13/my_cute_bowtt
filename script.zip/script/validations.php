<?php
    require_once("include/session.php");

    if(isset($_POST['no-errors'])){
        $ges->validateNoErrors();
    }elseif(isset($_POST['edit-validation'])){
        $ges->updateValidation();
    }

    if(isset($_GET['USER_ID'])){
        $user_id = $_GET['USER_ID'];
        $user = $ges->getUser($user_id);

        if(isset($_POST['delete-validation'])){
            $ges->deleteValidation($_POST['validation_id']);
        }elseif(isset($_POST['delete-validations-onqueue'])){
            $ges->deleteUserValidations($user_id, 0);
        }elseif(isset($_POST['delete-validations-without-errors'])){
            $ges->deleteUserValidations($user_id, 1);
        }elseif(isset($_POST['delete-validations-with-errors'])){
            $ges->deleteUserValidations($user_id, 2);
        }elseif(isset($_POST['delete-all-validations'])){
            $ges->deleteUserValidations($user_id);
        }

        if(isset($_GET['sort'])){
            $sort = $_GET['sort'];
            $validations = $ges->getUsersValidations($user_id, $sort);
        }else{
            $validations = $ges->getUsersValidations($user_id);
        }
    }elseif(isset($_GET['sort'])){
        $sort = $_GET['sort'];
        $validations = $ges->getValidationsWithStatus($sort);
    }else{
        header('Location: ./monitoring.php');
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>GES Validation</title>

        <!-- Styles -->
        <link href="public/css/bootstrap.min.css" rel="stylesheet">
        <link href="public/css/dataTables.bootstrap.min.css" rel="stylesheet" >
        <link href="public/css/ges.css" rel="stylesheet" >
        <link href="public/css/font-awesome.css" rel="stylesheet" >

        <!-- JavaScripts -->
        <script src="public/js/jquery.min.js"></script>
        <script src="public/js/jquery.dataTables.js"></script>

        <style>
            .table > tbody > tr > td {
                 vertical-align: middle;
            }
        </style>
    </head>
    <body>

        <?php require_once("layouts/navbar.php"); ?>

        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-2">
                    <h3 class="page-header">
                        <?php 
                            if(isset($user)) echo $user['NAME']."'s ";
                            if(isset($sort)){
                                if($sort == 0) echo "On Queue ";
                                elseif($sort == 1) echo "Finished ";
                            }
                        ?> Validations
                    </h3>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="panel panel-default">
                                    <div class="panel-body">  
                                        <?php
                                            if(isset($user_id)){
                                                if(isset($sort)){
                                                    if($sort == 0){

                                                        require_once("layouts/validations/users_onqueue.php");

                                                    }elseif($sort == 1){

                                                        require_once("layouts/validations/users_validated.php");

                                                    }
                                                }else{

                                                    require_once("layouts/validations/users_validations.php");

                                                }
                                            }elseif(isset($sort)){
                                                if($sort == 0){

                                                    require_once("layouts/validations/onqueue_validations.php");

                                                }elseif($sort == 1){

                                                    require_once("layouts/validations/finished_validations.php");

                                                }
                                            }
                                        ?>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
                if(isset($_SESSION['USER']) && $user_id == $_SESSION['USER']['ID']){
                    if(isset($user_id) && !isset($sort)){
                        require_once("layouts/validations/bulk_delete_buttons.php");
                    }
                }
            ?>
        </div>

        <script src="public/js/bootstrap.min.js"></script>
        <script src="public/js/dataTables.bootstrap.min.js"></script>
    </body>
</html>