<?php
	require_once("include/session.php");

	$ges->logActivity($_SESSION['USER']['ID'], 'Logout');

	session_destroy();
	header('Location: ' . $_SERVER['HTTP_REFERER']);
?>