<?php
	$DB_HOST = 'afodevsvr.maxim-ic.com';
	$DB_USERNAME = 'ges';
	$DB_PASSWORD = 'ges123';

	$DB_HOST2 = 'testweb2.maxim-ic.com';
	$DB_USERNAME2 = 'ges';
	$DB_PASSWORD2 = 'ges123';
?>