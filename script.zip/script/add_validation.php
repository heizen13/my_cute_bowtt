<?php
    require_once("include/session.php");

    if(isset($_POST['add_errors'])){
        $ges->validateWithErrors();
        header('Location: ./monitoring.php');
    }elseif(isset($_POST['upload_file'])){
        $errors_array = $ges->getErrorsFromFile();
    }

    if(!isset($_GET['validation_id'])){
        header('Location: ./monitoring.php');
    }

    $validation_id = $_GET['validation_id'];
    $validation = $ges->getValidationDetails($validation_id);

    if(!isset($_SESSION['USER']) || $validation['USER_ID'] <> $_SESSION['USER']['ID']){
        header('Location: ./monitoring.php');
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>GES Validation</title>

        <!-- Styles -->
        <link href="public/css/bootstrap.min.css" rel="stylesheet">
        <link href="public/css/dataTables.bootstrap.min.css" rel="stylesheet" >

        <!-- JavaScripts -->
        <script src="public/js/jquery.min.js"></script>
        <script src="public/js/jquery.dataTables.js"></script>

    </head>
    <body>

        <?php require_once("layouts/navbar.php"); ?>

        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-2">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-8">
                                <a href="#" data-toggle="modal" data-target="#upload_file_modal"  class="btn btn-primary btn-md">
                                    Upload File
                                </a>
                                <div id="upload_file_modal" class="modal fade" role="dialog">
                                    <div class="modal-dialog">     
                                        <div class="modal-content">
                                            <div class="modal-body">
                                                <div class="panel">
                                                    <div class="panel-body">
                                                        <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                                                            <div class="form-group">
                                                                <label class="col-md-4 control-label"> Upload File </label>
                                                                <div class="col-md-8">
                                                                    <input type="file" class="form-control" name="upfile"  required>
                                                                </div>
                                                            </div>

                                                            <input type="hidden" name="validation_id" <?php echo "value='".$validation_id."'"; ?> >
                                                            <input type="hidden" name="upload_file" value="1">

                                                            <div class="form-group">
                                                                <div class="col-md-2 col-md-offset-4">
                                                                    <button type="submit" class="btn btn-primary">
                                                                        Upload
                                                                    </button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <button class="btn btn-success btn-md" onClick="addRow('dataTable')">
                                    + Add Errors
                                </button>
                            </div>
                            <div class="col-md-2">
                                <button class="btn btn-danger btn-md" onClick="deleteRow('dataTable')">
                                    - Remove Errors
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <h4 class="page-header">Validate Part Number: <?php echo $validation['PART_NUMBER']; ?> </h4>
                                    <form method="POST" enctype="multipart/form-data">
                                          
                                        <table id="dataTable" class="form" width="100%">
                                            <tbody>
                                                <?php
                                                    if(isset($errors_array)){
                                                        foreach($errors_array as $error){
                                                            ?>
                                                                <tr>
                                                                    <td>
                                                                        <div class="form-group">
                                                                            <div class="col-md-2 col-md-offset-1">
                                                                                <label> Seq No </label>
                                                                                <input type="text" class="form-control" name="seq_nos[]" <?php echo "value='".$error[0]."'"; ?> required />
                                                                            </div>
                                                                            <div class="col-md-7 col-md-offset-1">
                                                                                <label> Error Description </label>
                                                                                <textarea class="form-control" name="errors[]" cols="50" required><?php echo $error[1]; ?></textarea>
                                                                            </div>
                                                                        </div>

                                                                        <div class="page-header">
                                                                            <br/><br/><br/><br/>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                            <?php
                                                        }
                                                    }else{
                                                ?>
                                                    <tr>
                                                        <td>
                                                            <div class="form-group">
                                                                <div class="col-md-2 col-md-offset-1">
                                                                    <label> Seq No </label>
                                                                    <input type="text" class="form-control" name="seq_nos[]" required />
                                                                </div>
                                                                <div class="col-md-7 col-md-offset-1">
                                                                    <label> Error Description </label>
                                                                    <textarea class="form-control" name="errors[]" cols="50" required></textarea>
                                                                </div>
                                                            </div>

                                                            <div class="page-header">
                                                                <br/><br/><br/><br/>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php
                                                    }
                                                ?>
                                            </tbody>
                                        </table>

                                        <input type="hidden" name="validation_id" <?php echo "value='".$validation_id."'"; ?> >
                                        <input type="hidden" name="part_number" <?php echo "value='".$validation['PART_NUMBER']."'"; ?> >
                                        <input type="hidden" name="routing_type" <?php echo "value='".$validation['ROUTING_TYPE']."'"; ?> >
                                        <input type="hidden" name="add_errors" value="1">

                                        <div class="form-group">
                                            <div class="col-md-2 col-md-offset-1">
                                                <button type="submit" class="btn btn-primary" onclick="return confirm('You are about to submit the errors.')" >
                                                    Submit
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="public/js/bootstrap.min.js"></script>
        <script src="public/js/dataTables.bootstrap.min.js"></script>
        <script>
            function addRow(tableID) {
                var table = document.getElementById(tableID);
                var rowCount = table.rows.length;
                var row = table.insertRow(rowCount);
                var colCount = table.rows[0].cells.length;
                for(var i=0; i <colCount; i++) {
                    var newcell = row.insertCell(i);
                    newcell.innerHTML = table.rows[0].cells[i].innerHTML;
                }
            }

            function deleteRow(tableID) {
                var table = document.getElementById(tableID);
                var rowCount = table.rows.length;
                for(var i=0; i<rowCount; i++) {
                    if(rowCount <= 1) {
                        break;
                    }
                    table.deleteRow(rowCount-1);
                }
            }
        </script>
    </body>
</html>
