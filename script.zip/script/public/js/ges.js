var eventHandlers = {
	init: function(){

		$("#optional-fields-label a").on("click", function(e){
			$target = $(e.target);

			if($target.text() == 'Show Additional Fields'){
				$target.text('Hide Additional Fields');
			}else{
				$target.text('Show Additional Fields');
			}

			$("#optional-fields-radio").toggle(200);
			$("#optional-fields-setup-no").toggle(200);
		});

		$(".toggle-row").on("click", function(e){
			$target = $(e.currentTarget);
			$children = $target.children();
			$children.toggleClass("toggle-on");
		});
	}
};

$(document).ready( function(){
	eventHandlers.init();
});