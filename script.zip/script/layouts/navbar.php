<nav class="navbar navbar-default">
    <div class="container">
        <div class="navbar-header">
            <a class="navbar-brand" href="index.php">
                GES Validation
            </a>
        </div>
        <ul class="nav navbar-nav navbar-right">
            <li><a href="monitoring.php"> Monitoring </a></li>
            <?php if(!isset($_SESSION['USER'])){ ?>
                <li><a href="#" data-toggle="modal" data-target="#login"> Log In </a></li>
            <?php }else{ ?>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <?php echo $_SESSION['USER']['NAME']; ?><span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu">
                        <li><a href="#" data-toggle="modal" data-target="#changeUsernameModal"> Change Username </a></li>
                        <li><a href="#" data-toggle="modal" data-target="#changePasswordModal"> Change Password </a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </li>

            <?php } ?>
        </ul>

        <div id="login" class="modal fade" role="dialog">
            <div class="modal-dialog">     
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <div class="panel-body">
                                    <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label class="col-md-3 col-md-offset-1 control-label"> Username </label>
                                            <div class="col-md-5">
                                                <input type="text" class="form-control" name="username" required autofocus />
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-3 col-md-offset-1 control-label"> Password </label>
                                            <div class="col-md-5">
                                                <input type="password" class="form-control" name="password" required />
                                            </div>
                                        </div>

                                        <input type="hidden" name="login_submit" value="1">

                                        <div class="form-group">
                                            <div class="col-md-2 col-md-offset-4">
                                                <button type="submit" class="btn btn-primary";>
                                                    Login
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="changeUsernameModal" class="modal fade" role="dialog">
            <div class="modal-dialog">     
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="panel-body">
                                    <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label class="col-md-4 control-label">Current Username </label>
                                            <div class="col-md-7">
                                                <input type="text" class="form-control" <?php echo "value='".$_SESSION['USER']['USERNAME']."'";?> disabled />
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-4 control-label"> New Username </label>
                                            <div class="col-md-7">
                                                <input type="text" class="form-control" name="new_username" autofocus required>
                                            </div>
                                        </div>

                                        <input type="hidden" name="new_username_submit" value="1">

                                        <div class="form-group">
                                            <div class="col-md-2 col-md-offset-4">
                                                <button type="submit" class="btn btn-primary" onclick="return confirm('You are about to change your Username.')";>
                                                    Submit
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="changePasswordModal" class="modal fade" role="dialog">
            <div class="modal-dialog">     
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="panel-body">
                                    <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                                        <div class="form-group">
                                            <label class="col-md-4 control-label">Current Password </label>
                                            <div class="col-md-7">
                                                <input type="password" class="form-control" name="old_password" autofocus required />
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="col-md-4 control-label"> New Password </label>
                                            <div class="col-md-7">
                                                <input type="password" class="form-control" name="new_password" required>
                                            </div>
                                        </div>

                                        <input type="hidden" name="new_password_submit" value="1">

                                        <div class="form-group">
                                            <div class="col-md-2 col-md-offset-4">
                                                <button type="submit" class="btn btn-primary" onclick="return confirm('You are about to change your Password.')";>
                                                    Submit
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</nav>
<?php if(isset($error_status)){ ?>
    <div class="alert alert-danger">
        <strong><center><?php echo $error_status; ?></center></strong>
    </div>
<?php } ?>