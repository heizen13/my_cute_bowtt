<a href="#" data-toggle="modal" <?php echo "data-target='#edit-val-".$i."'"; ?> class="btn btn-success btn-sm">
    Edit
</a>
<div <?php echo "id='edit-val-".$i."'"; ?> class="modal fade" role="dialog">
    <div class="modal-dialog">     
        <div class="modal-content">
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <h4 class="page-header"> Edit <?php echo $values['PART_NUMBER']; ?> <button type="button" class="close" data-dismiss="modal">&times;</button></h4>
                        <div class="panel-body" align="left">
                            <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="validation_id" <?php echo "value='".$values['ID']."'"; ?>>
                                <input type="hidden" name="edit-validation" value="1">
                                
                                <div class="panel-body">
                                    <div class="row">
                                        <label class="col-md-3 control-label"> Part Number </label>
                                        <div class="col-md-2">
                                            <input type="text" class="form-control" name="edit_part_number" <?php echo "value='".$values['PART_NUMBER']."'"; ?> required>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <label class="col-md-3 control-label"> Routing Type </label>
                                        <div class="col-md-2">
                                            <input type="text" class="form-control" name="edit_routing_type" <?php echo "value='".$values['ROUTING_TYPE']."'"; ?> maxlength="1" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <div class="row">
                                        <label class="col-md-3 control-label"></label>
                                        <div class="col-md-3">
                                            <button type="submit" class="btn btn-primary">
                                                Save
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>