<table class="table table-hover table-bordered" id="finished-validations-table" data-order='[[ 4, "desc" ]]' width="100%">
    <thead>    
        <tr>
            <th>Part Number</th>
            <th>Routing Type</th>
            <th>Status</th>
            <th>Error Count</th>
            <th>Date Validated</th>
            <th>Validator</th>
        </tr>
    </thead>
    <tbody>
        <?php
            foreach($validations as $values){
                echo "<tr>";
                echo "<td>".$values['PART_NUMBER']."</td>";
                echo "<td>".$values['ROUTING_TYPE']."</td>";
                
                if($values['HAS_ERRORS'] == 1){
                    echo "<td class='text-danger'> Validated (with errors) </td>";
                }else{
                    echo "<td class='text-success'> Validated </td>";
                }
                
                echo "<td align='right'> <a href='errors.php?validation_id=".$values['ID']."'>".$values['ERROR_COUNT']."</a> </td>";
                echo "<td>".$values['DATE_VALIDATED']."</td>";
                echo "<td>".$values['NAME']."</td>";
                echo "</tr>";
            }
        ?>
    </tbody>
</table>

<script>
    $(document).ready( function () {
        $('#finished-validations-table').DataTable({
            "lengthMenu": [[-1, 20, 50],['All', 20, 50]]              
        });
    });
</script>