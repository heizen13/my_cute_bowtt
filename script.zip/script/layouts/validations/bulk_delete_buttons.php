<div class="row">
    <div class="panel">
        <div class="panel-body">
            <div class="col-md-10 col-md-offset-2">
                <table class="table-condensed pull-right">
                    <tr>
                        <td>
                            <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="user_id" <?php echo "value='".$user_id."'"; ?>>
                                <input type="hidden" name="delete-validations-onqueue" value="1">
                                
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('WARNING!\nYou are about to delete all On Queue Validations of this User.');">
                                    Delete All On Queue
                                </button>
                            </form>
                        </td>
                        <td>
                            <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="user_id" <?php echo "value='".$user_id."'"; ?>>
                                <input type="hidden" name="delete-validations-without-errors" value="1">
                                
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('WARNING!\nYou are about to delete All Validations without Errors of this User.');">
                                    Delete All Validated Without Errors
                                </button>
                            </form>
                        </td>
                        <td>
                            <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="user_id" <?php echo "value='".$user_id."'"; ?>>
                                <input type="hidden" name="delete-validations-with-errors" value="1">
                                
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('WARNING!\nYou are about to delete All Validations with Errors of this User.');">
                                    Delete All Validated With Errors
                                </button>
                            </form>
                        </td>
                        <td>
                            <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="user_id" <?php echo "value='".$user_id."'"; ?>>
                                <input type="hidden" name="delete-all-validations" value="1">
                                
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('WARNING!\nYou are about to delete All Validations of this User.');">
                                    Delete All Validations
                                </button>
                            </form>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>