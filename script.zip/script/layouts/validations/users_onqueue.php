<table class="table table-hover table-bordered" <?php echo isset($_SESSION['USER']) && $user_id == $_SESSION['USER']['ID'] ? "id='users-onqueue-table'" : "id='users-onqueue-table-guest'" ?> width="100%">
    <thead>    
        <tr>
            <th>Part Number</th>
            <th class="col-md-2">Routing Type</th>
            <th>Status</th>
            <?php
                if(isset($_SESSION['USER']) && $user_id == $_SESSION['USER']['ID']){
                    echo "<th></th>";
                }
            ?>
        </tr>
    </thead>
    <tbody>
        <?php
            $i = 1;
            foreach($validations as $values){
                echo "<tr>";
                    echo "<td>".$values['PART_NUMBER']."</td>";
                    echo "<td>".$values['ROUTING_TYPE']."</td>";
                    echo "<td> On Queue </td>";

                    if(isset($_SESSION['USER']) && $user_id == $_SESSION['USER']['ID']){
                        echo "<td align='center'>";
                            require("layouts/validations/edit_button.php");
                            require("layouts/validations/validate_button.php");
                        echo "</td>";
                    }

                echo "</tr>";
                $i++;
            }
        ?>
    </tbody>
</table>
<script>
    $(document).ready( function () {
        $('#users-onqueue-table').DataTable({
            "lengthMenu": [[-1, 20, 50],['All', 20, 50]],
            "columnDefs": [{ 
                "targets": 3,
                "orderable": false
            }]
        });
        $('#users-onqueue-table-guest').DataTable({
            "lengthMenu": [[-1, 20, 50],['All', 20, 50]]
        });
    });
</script>