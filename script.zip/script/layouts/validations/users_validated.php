<table class="table table-hover table-bordered" <?php echo isset($_SESSION['USER']) && $user_id == $_SESSION['USER']['ID'] ? "id='users-validated-table'" : "id='users-validated-table-guest'" ?> data-order='[[ 4, "desc" ]]' width="100%">
    <thead>    
        <tr>
            <th>Part Number</th>
            <th class="col-md-2">Routing Type</th>
            <th>Status</th>
            <th>Error Count</th>
            <th>Date Validated</th>
            <?php 
                if(isset($_SESSION['USER']) && $user_id == $_SESSION['USER']['ID']){
                    echo "<th></th>";
                }
            ?>
        </tr>
    </thead>
    <tbody>
        <?php
            $i = 1;
            foreach($validations as $values){
                echo "<tr>";
                    echo "<td>".$values['PART_NUMBER']."</td>";
                    echo "<td>".$values['ROUTING_TYPE']."</td>";
                    
                    if($values['HAS_ERRORS'] == 1){
                        echo "<td class='text-danger'> Validated (with errors) </td>";
                    }else{
                        echo "<td class='text-success'> Validated </td>";
                    }
                    
                    echo "<td align='right'> <a href='errors.php?validation_id=".$values['ID']."'>".$values['ERROR_COUNT']."</a> </td>";
                    echo "<td>".$values['DATE_VALIDATED']."</td>";

                    if(isset($_SESSION['USER']) && $user_id == $_SESSION['USER']['ID']){
                        echo "<td align='center'>"; 
                            require("layouts/validations/edit_button.php");
                        echo "</td>";
                    }

                echo "</tr>";
                $i++;
            }
        ?>
    </tbody>
</table>
<script>
    $(document).ready( function () {
        $('#users-validated-table').DataTable({
            "lengthMenu": [[-1, 20, 50],['All', 20, 50]],
            "columnDefs": [{ 
                "targets": 5,
                "orderable": false
            }]
        });

        $('#users-validated-table-guest').DataTable({
            "lengthMenu": [[-1, 20, 50],['All', 20, 50]]
        });
    });
</script>