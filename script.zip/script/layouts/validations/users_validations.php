<table class="table table-hover table-bordered" <?php echo isset($_SESSION['USER']) && $user_id == $_SESSION['USER']['ID'] ? "id='users-validations-table'" : "id='users-validations-table-guest'"; ?> width="100%">
    <thead>    
        <tr>
            <th>Part Number</th>
            <th class="col-md-2">Routing Type</th>
            <th>Status</th>
            <?php
                if(isset($_SESSION['USER']) && $user_id == $_SESSION['USER']['ID']){
                    echo "<th></th>";
                }
            ?>
        </tr>
    </thead>
    <tbody>
        <?php
            $i = 1;
            foreach($validations as $values){
                echo "<tr>";

                    echo "<td>".$values['PART_NUMBER']."</td>";
                    echo "<td>".$values['ROUTING_TYPE']."</td>";

                    if($values['STATUS'] == 0){
                        echo "<td> On Queue </td>";
                    }else{
                        if($values['HAS_ERRORS'] == 1){
                            echo "<td class='text-danger'> Validated (with errors) </td>";
                        }else{
                            echo "<td class='text-success'> Validated </td>";
                        }
                    }

                    if(isset($_SESSION['USER']) && $user_id == $_SESSION['USER']['ID']){
                        echo "<td align='center'>";
                            echo "<table class='table-condensed'>";
                                echo "<tr>";
                                    echo "<td>";
                                        require("layouts/validations/edit_button.php");
                                    echo "</td>";
                                    echo "<td>";
                                         require("layouts/validations/delete_button.php");
                                    echo "</td>";
                                echo "</tr>";
                            echo "</table>";
                        echo "</td>";
                    }

                echo "</tr>";
                $i++;
            }
        ?>
    </tbody>
</table>
<script>
    $(document).ready( function () {
        $('#users-validations-table').DataTable({
            "lengthMenu": [[-1, 20, 50],['All', 20, 50]],
            "columnDefs": [{ 
                "targets": 3,
                "orderable": false
            }]
        });
        $('#users-validations-table-guest').DataTable({
            "lengthMenu": [[-1, 20, 50],['All', 20, 50]]
        });
    });
</script>