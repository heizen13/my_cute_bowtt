<a href="#" data-toggle="modal" <?php echo "data-target='#validate-".$i."'"; ?> class="btn btn-primary btn-sm">
    Validate
</a>
<div <?php echo "id='validate-".$i."'"; ?> class="modal fade" role="dialog">
    <div class="modal-dialog">     
        <div class="modal-content">
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <h4 class="page-header"> Validate <?php echo $values['PART_NUMBER']; ?> <button type="button" class="close" data-dismiss="modal">&times;</button></h4>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-md-5">
                                    <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                                        <input type="hidden" name="validation_id" <?php echo "value='".$values['ID']."'"; ?>>
                                        <input type="hidden" name="no-errors" value="1">
                                        <input type="hidden" name="part_number" <?php echo "value='".$values['PART_NUMBER']."'"; ?>>
                                        <input type="hidden" name="routing_type" <?php echo "value='".$values['ROUTING_TYPE']."'"; ?>>

                                        <div class="form-group">
                                            <div class="col-md-2 col-md-offset-3">
                                                <button type="submit" class="btn btn-success" onclick="return confirm('Validation has No Errors. \nAre you sure?');">
                                                    No Errors
                                                </button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                <div class="col-md-6">
                                    <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                                        <input type="hidden" name="part_number" <?php echo "value='".$values['PART_NUMBER']."'"; ?>>
                                        <input type="hidden" name="has-errors" value="1">

                                        <div class="form-group">
                                            <div class="col-md-2 col-md-offset-3">
                                                <a <?php echo "href='add_validation.php?validation_id=".$values['ID']."'"; ?> href="add_validation.php" class="btn btn-danger">
                                                    Has Errors
                                                </a>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>