<form class="form-horizontal" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="validation_id" <?php echo "value='".$values['ID']."'"; ?>>
    <input type="hidden" name="part_number" <?php echo "value='".$values['PART_NUMBER']."'"; ?>>
    <input type="hidden" name="routing_type" <?php echo "value='".$values['ROUTING_TYPE']."'"; ?>>
    <input type="hidden" name="delete-validation" value="1">
    
    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('You are about to delete a validation.');">
        Delete
    </button>
</form>