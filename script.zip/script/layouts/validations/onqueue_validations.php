<table class="table table-hover table-bordered" id="onqueue-validations-table" width="100%">
    <thead>    
        <tr>
            <th>Part Number</th>
            <th class="col-md-2">Routing Type</th>
            <th>Status</th>
            <th>Validator</th>
        </tr>
    </thead>
    <tbody>
        <?php
            foreach($validations as $values){
                echo "<tr>";
                echo "<td>".$values['PART_NUMBER']."</td>";
                echo "<td>".$values['ROUTING_TYPE']."</td>";
                echo "<td> On Queue </td>";
                echo "<td>".$values['NAME']."</td>";
                echo "</tr>";
            }
        ?>
    </tbody>
</table>

<script>
    $(document).ready( function () {
        $('#onqueue-validations-table').DataTable({
            "lengthMenu": [[-1, 20, 50],['All', 20, 50]]                
        });
    });
</script>