<div class="page-header">
    <h4> Errors of Part Number: <b> <?php echo $validation['PART_NUMBER']; ?> </b> </h4> 
    
    <?php if(isset($_SESSION['USER']) && $user['ID'] == $_SESSION['USER']['ID']) { ?>
        <a <?php echo "href='add_validation.php?validation_id=".$validation_id."'"; ?> class="btn btn-success btn-md pull-right"> Add More Errors </a>
    <?php } ?>

    Routing Type: <b><?php echo $validation['ROUTING_TYPE']; ?> </b><br/>
    Validator: <b><?php echo $user['NAME']; ?></b>
</div>
<div class="panel panel-default">
    <div class="panel-body">
        <div class="row">
            <div class="col-md-12">
                <table class="table table-hover table-bordered" <?php echo isset($_SESSION['USER']) && $user['ID'] == $_SESSION['USER']['ID'] ? "id='validation-errors-table'" : "id='validation-errors-table-guest'" ?> width="100%" data-order='[[ 0, "asc" ]]'>
                    <thead>    
                        <tr>
                            <th>Seq No</th>
                            <th>Error Description</th>
                            <th>Status</th>
                            <th>Date Fixed</th>
                            <?php
                                if(isset($_SESSION['USER']) && $user['ID'] == $_SESSION['USER']['ID']) {
                                    echo "<th class='col-md-3'></th>";
                                }
                            ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if(isset($errors) && count($errors) > 0){
                                $i = 1;
                                foreach($errors as $error){
                                    echo "<tr>";
                                        echo "<td>".$error['SEQ_NO']."</td>";
                                        echo "<td>".$error['DESCRIPTION']."</td>";

                                        if($error['STATUS'] == 1){
                                            echo "<td class='text-success'> Fixed </td>";
                                            echo "<td> ".$error['DATE_FIXED']." </td>";
                                        }else{
                                            echo "<td class='text-danger'> Unfixed </td>";
                                            echo "<td> - </td>";
                                        }

                                        if(isset($_SESSION['USER']) && $user['ID'] == $_SESSION['USER']['ID']) {
                                            echo "<td align='center'>";
                                                echo "<table class='table-condensed'>";
                                                    echo "<tr>";
                                                            if($error['STATUS'] == 0){
                                                                echo "<td>";
                                                                    require("layouts/errors/set_to_fixed_button.php");
                                                                echo "</td>";
                                                            }

                                                            echo "<td>";
                                                                require("layouts/errors/edit_button.php");
                                                            echo "</td>";
                                                            echo "<td>";
                                                                require("layouts/errors/delete_button.php");
                                                            echo "</td>";
                                                    echo "</tr>";
                                                echo "</table>";
                                            echo "</td>";
                                        }

                                    echo "</tr>";
                                    $i++;
                                }
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready( function () {
        $('#validation-errors-table').DataTable({
            pagingType: 'simple',
            "columnDefs": [{ 
                "targets": 4,
                "orderable": false
            }],
            "lengthMenu": [[-1, 20, 50],['All', 20, 50]]

        });$('#validation-errors-table-guest').DataTable({
            pagingType: 'simple',
            "lengthMenu": [[-1, 20, 50],['All', 20, 50]]
        });
    });
</script>