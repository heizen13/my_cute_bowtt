<a href="#" data-toggle="modal" <?php echo "data-target='#edit-error-".$i."'"; ?> class="btn btn-success btn-sm">
    Edit
</a>
<div <?php echo "id='edit-error-".$i."'"; ?> class="modal fade" role="dialog">
    <div class="modal-dialog">     
        <div class="modal-content">
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12">
                        <h4 class="page-header"> Edit Error <button type="button" class="close" data-dismiss="modal">&times;</button></h4>
                        <div class="panel-body" align="left">
                            <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                                <input type="hidden" name="error_id" <?php echo "value='".$error['ID']."'"; ?>>
                                <input type="hidden" name="part_number" <?php echo "value='".$validation['PART_NUMBER']."'";?>>
                                <input type="hidden" name="routing_type" <?php echo "value='".$validation['ROUTING_TYPE']."'";?>>
                                <input type="hidden" name="edit-error" value="1">

                                <div class="panel-body">
                                    <div class="row">
                                        <label class="col-md-4 control-label"> Seq No </label>
                                        <div class="col-md-1">
                                            <input type="text" class="form-control" name="edit_seq_no" <?php echo "value='".$error['SEQ_NO']."'"; ?> required>
                                        </div>
                                    </div>
                                </div>

                                <div class="panel-body">
                                    <div class="row">
                                        <label class="col-md-4 control-label"> Error Description </label>
                                        <div class="col-md-4">
                                            <textarea class="form-control" name="edit_description" rows="5" cols="40" required><?php echo $error['DESCRIPTION']; ?></textarea>
                                        </div>
                                    </div>
                                </div>

                                <div class="panel-body">
                                    <div class="row">
                                        <label class="col-md-4 control-label"></label>
                                        <div class="col-md-3">
                                            <button type="submit" class="btn btn-primary">
                                                Save
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>