<form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="error_id" <?php echo "value='".$error['ID']."'"; ?>>
    <input type="hidden" name="part_number" <?php echo "value='".$validation['PART_NUMBER']."'";?>>
    <input type="hidden" name="routing_type" <?php echo "value='".$validation['ROUTING_TYPE']."'";?>>
    <input type="hidden" name="delete_error" value="1">

    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('You are about to delete an error.');">
        Delete
    </button>
</form>