<div class="page-header">
<h3>
    Errors Found
    <div class="pull-right">
        <form class="form-horizontal" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="generate_excel" value="1">
            
            <button type="submit" class="btn btn-success btn-sm">
                Generate Spreadsheet
            </button>
        </form>
    </div>
</h3>
</div>
<div class="panel panel-default">
    <div class="panel-body">
        <div class="row">
            <div class="col-md-12">
                <table class="table table-hover table-bordered" id="all-errors-table" data-order='[[ 4, "desc" ]]' width="100%">
                    <thead>    
                        <tr>
                            <th class="col-md-2">Part Number</th>
                            <th>Routing Type</th>
                            <th>Seq No</th>
                            <th class="col-md-4">Error Description</th>
                            <th>Date Validated</th>
                            <th>Validator</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if(isset($errors) && count($errors) > 0){
                                foreach($errors as $error){
                                    echo "<tr>";
                                    echo "<td>".$error['PART_NUMBER']."</td>";
                                    echo "<td>".$error['ROUTING_TYPE']."</td>";
                                    echo "<td>".$error['SEQ_NO']."</td>";
                                    echo "<td class='error-desc'>".$error['DESCRIPTION']."</td>";
                                    echo "<td> ".$error['DATE_VALIDATED']." </td>";
                                    echo "<td>".$error['NAME']."</td>";

                                    echo "</tr>";
                                }
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>