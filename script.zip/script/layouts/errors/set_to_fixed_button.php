<form method="POST" enctype="multipart/form-data">
    <input type="hidden" name="error_id" <?php echo "value='".$error['ID']."'"; ?>>
    <input type="hidden" name="fix_error" value="1">

    <button type="submit" class="btn btn-info btn-sm">
        Set to Fixed
    </button>
</form>