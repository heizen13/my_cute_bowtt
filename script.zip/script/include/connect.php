<?php
	require("./configs.php");
	date_default_timezone_set('Asia/Brunei');

	$mysqli = new mysqli($DB_HOST, $DB_USERNAME, $DB_PASSWORD);

	$mysqli_testweb2 = new mysqli($DB_HOST2, $DB_USERNAME2, $DB_PASSWORD2);
	
	if ($mysqli->connect_errno){
    	echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
	}elseif ($mysqli_testweb2->connect_errno){
    	echo "Failed to connect to MySQL: (" . $mysqli_testweb2->connect_errno . ") " . $mysqli_testweb2->connect_error;
	}
?>