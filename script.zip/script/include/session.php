<?php
    session_start();
    require_once("include/ges.php");
    $ges = new GES();

    if(isset($_POST['login_submit'])){
        $user = $ges->login($_POST['username'], $_POST['password']);

        if(!empty($user)){
        	$_SESSION['USER'] = $user;
        }else{
        	$error_status = "Wrong Username or Password!";
        }
    }elseif(isset($_POST['new_username_submit'])){
        $ges->changeUsername($_POST['new_username'], $_SESSION['USER']['ID']);
    }elseif(isset($_POST['new_password_submit'])){
        $success = $ges->changePassword($_POST['old_password'], $_POST['new_password'], $_SESSION['USER']['ID']);

        if(!$success){
        	$error_status = "Wrong Current Password!";
        }
    }
?>