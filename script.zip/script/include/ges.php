<?php

class GES
{		

	public function addValidation()
	{
		include "connect.php";

		$part_numbers = explode(",",$_POST['part_num']);
		$stmt = $mysqli->prepare("INSERT INTO ges_validations.validations
									(
										PART_NUMBER,
										ROUTING_TYPE,
										USER_ID,
										STATUS,
										HAS_ERRORS
									)
									VALUES
									(
										?,
										?,
										?,
										0,
										0
									)");
		foreach($part_numbers as $part_number){
			$part_number = trim($part_number);

			$stmt->bind_param("ssi", $part_number, $_POST['routing_type'], $_POST['user_id']);
			$stmt->execute();
			$stmt->free_result();
		}
		$stmt->close();
		$this->logActivity($_POST['user_id'], 'Added On Queue Validation/s');
		
	}

	public function getStats($date_start, $date_end)
	{
		include "connect.php";

		$query = $mysqli->query("SELECT 
									u.NAME, 
									COUNT(CASE WHEN v.STATUS = 1 AND v.DATE_VALIDATED >= '".$date_start."' AND '".$date_end."' THEN 1 END) as VALIDATED,
									COUNT(CASE WHEN v.STATUS = 1 AND v.HAS_ERRORS = 0 AND v.DATE_VALIDATED BETWEEN '".$date_start."' AND '".$date_end."' THEN 1 END) as NO_ERRORS,
									COUNT(CASE WHEN v.STATUS = 1 AND v.HAS_ERRORS = 1 AND v.DATE_VALIDATED BETWEEN '".$date_start."' AND '".$date_end."' THEN 1 END) as HAS_ERRORS
								FROM ges_validations.users u
								LEFT JOIN ges_validations.validations v
									ON v.USER_ID = u.id
								GROUP BY u.ID;");

		$all_arrays = array();
		while($row = $query->fetch_assoc()){
			$all_arrays[]=$row;
		}
		
		return $all_arrays;
	}

	public function getDailyStats()
	{
		include "connect.php";

		$query = $mysqli->query("SELECT 
									u.NAME, 
									COUNT(CASE WHEN v.STATUS = 1 AND v.DATE_VALIDATED = '".date('Y-m-d', strtotime('-6 days'))."' THEN 1 END) as ONE,
									COUNT(CASE WHEN v.STATUS = 1 AND v.DATE_VALIDATED = '".date('Y-m-d', strtotime('-5 days'))."' THEN 1 END) as TWO,
									COUNT(CASE WHEN v.STATUS = 1 AND v.DATE_VALIDATED = '".date('Y-m-d', strtotime('-4 days'))."' THEN 1 END) as THREE,
									COUNT(CASE WHEN v.STATUS = 1 AND v.DATE_VALIDATED = '".date('Y-m-d', strtotime('-3 days'))."' THEN 1 END) as FOUR,
									COUNT(CASE WHEN v.STATUS = 1 AND v.DATE_VALIDATED = '".date('Y-m-d', strtotime('-2 days'))."' THEN 1 END) as FIVE,
									COUNT(CASE WHEN v.STATUS = 1 AND v.DATE_VALIDATED = '".date('Y-m-d', strtotime('-1 days'))."' THEN 1 END) as SIX,
									COUNT(CASE WHEN v.STATUS = 1 AND v.DATE_VALIDATED = '".date('Y-m-d')."' THEN 1 END) as SEVEN,
									COUNT(CASE WHEN v.STATUS = 1 AND v.DATE_VALIDATED BETWEEN '".date('Y-m-d', strtotime('-6 days'))."' AND '".date('Y-m-d')."' THEN 1 END) as TOTAL
								FROM ges_validations.users u
								LEFT JOIN ges_validations.validations v
									ON v.USER_ID = u.id
								GROUP BY u.ID;");

		$all_arrays = array();
		while($row = $query->fetch_assoc()){
			$all_arrays[]=$row;
		}
		
		return $all_arrays;
	}

	public function getOverallStats()
	{
		include "connect.php";

		$query = $mysqli->query("SELECT 
									u.NAME,
									COUNT(CASE WHEN v.STATUS = 1 THEN 1 END) as VALIDATED,
									COUNT(CASE WHEN v.STATUS = 1 AND v.HAS_ERRORS = 0 THEN 1 END) as NO_ERRORS,
									COUNT(CASE WHEN v.STATUS = 1 AND v.HAS_ERRORS = 1 THEN 1 END) as HAS_ERRORS
								FROM ges_validations.users u
								LEFT JOIN ges_validations.validations v
									ON v.USER_ID = u.id
								GROUP BY u.ID;");

		$all_arrays = array();
		while($row = $query->fetch_assoc()){
			$all_arrays[] = $row;
		}
		
		return $all_arrays;
	}

	public function getPartNumDetails($part_number, $routing_type, $start_setup_no, $end_setup_no)
	{
		include "connect.php";

		$query = "SELECT
					OPERATION_SEQ_NO, 
					GREATEST(SETUP_NO - (? - 1), 0) AS SETUP_NO,
					OPERATION_CODE,
					STEP_TYPE_CODE, 
					TOOL_TYPE, 
					CASE WHEN TOOL_TYPE = 'SETN' THEN
						REPLACE(TOOLING_PART_NO, SETUP_NO, GREATEST(SETUP_NO - (? - 1), 0))
					ELSE
						TOOLING_PART_NO
					END AS TOOLING_PART_NO
				 FROM maxcim_conversion.route_ids 
				 WHERE PART_NUMBER = ?
				 	AND ROUTING_TYPE = ?
				 	AND (
				 		SETUP_NO BETWEEN ? AND ?
				 		OR SETUP_NO = 0
				 	)";

		$stmt = $mysqli->stmt_init();
		if(!$stmt->prepare($query)){
		    print "Failed to prepare statement - ".htmlspecialchars($mysqli->error);
		}else{
		    $stmt->bind_param("iissii", $start_setup_no, $start_setup_no, $part_number, $routing_type, $start_setup_no, $end_setup_no);

		   	$stmt->execute();
	        $result = $stmt->get_result();
	        $all_arrays = array();
	        while ($row = $result->fetch_array(MYSQLI_NUM)){
	            $all_arrays[] = $row;
	        }
		}
		
		$stmt->close();
		$mysqli->close();
		
		return $all_arrays;
	}

	public function getPartNumDetails2($part_number, $rc_id, $routing_type, $process_type)
	{
		include "connect.php";

		$query = $mysqli_testweb2->query("SELECT 
									PART_NUMBER, 
									OPERATION_SEQ_NO,
									OPERATION_CODE, 
									SETUP_NO, 
									STEP_TYPE_NAME, 
									TOOL_TYPE, 
									TOOLING_PART_NO,
									TOOL_DESCRIPTION
								 FROM route_builder.v_xrots
								 WHERE 
								 	RC_ID = ". $rc_id ."
								 	AND PART_NUMBER = '".$part_number."'
								 ORDER BY OPERATION_SEQ_NO, SETUP_NO, TOOL_TYPE");
		$all_arrays = array();
		while($row = $query->fetch_assoc()){
			$all_arrays[]=$row;
		}
		

		if($process_type == 1 || $process_type == 2){

			$query2 = $mysqli->query("DELETE
									  FROM ges_validations.route_ids_chino
									  WHERE PART_NUMBER = '".$part_number."'
									  	AND ROUTING_TYPE = '".$routing_type."'
									  	AND RC_ID = ".$rc_id."");
			$mysqli->query($query2);

			$query_str_insert = "INSERT INTO ges_validations.route_ids_chino (
									RC_ID,
									PART_NUMBER,
									ROUTING_TYPE,
									OPERATION_SEQ_NO,
									SETUP_NO,
									OPERATION_CODE,
									STEP_TYPE_CODE,
									TOOL_TYPE,
									TOOLING_PART_NO,
									TOOL_DESCRIPTION)
								VALUES ";

			foreach($all_arrays as $values){
				$query_str_insert .= "(". $rc_id .", '".$values['PART_NUMBER']."','".$routing_type."',".$values['OPERATION_SEQ_NO'].",".$values['SETUP_NO'].",".$values['OPERATION_CODE'].",'".$values['STEP_TYPE_NAME']."','".$values['TOOL_TYPE']."','".addslashes($values['TOOLING_PART_NO'])."','".addslashes($values['TOOL_DESCRIPTION'])."'), ";
			}

			$query_str_insert = rtrim($query_str_insert,", ");
			$mysqli->query($query_str_insert);
		}

		return $all_arrays;
	}

	public function getUser($id)
	{
		include "connect.php";

		$query = $mysqli->query("SELECT ID, NAME
								FROM ges_validations.users
								WHERE ID = ".$id);
		$row = $query->fetch_assoc();
		
		return $row;
	}

	public function getUsers()
	{
		include "connect.php";

		$query = $mysqli->query("SELECT ID, NAME, USERNAME
								FROM ges_validations.users");
		$all_arrays = array();
		while($row = $query->fetch_assoc()){
			$all_arrays[]=$row;
		}
		
		return $all_arrays;
	}

	public function getUsersStats()
	{
		include "connect.php";

		$query = $mysqli->query("SELECT 
									u.ID, 
									u.NAME, 
									COUNT(CASE WHEN v.STATUS = 0 THEN 1 END) as ONQUEUE, 
									COUNT(CASE WHEN v.STATUS = 1 THEN 1 END) as VALIDATED,
									COUNT(CASE WHEN v.STATUS = 1 AND v.HAS_ERRORS = 0 THEN 1 END) as NO_ERRORS,
									COUNT(CASE WHEN v.STATUS = 1 AND v.HAS_ERRORS = 1 THEN 1 END) as HAS_ERRORS
								FROM ges_validations.users u
								LEFT JOIN ges_validations.validations v
									ON v.USER_ID = u.id
								GROUP BY u.ID;");

		$all_arrays = array();
		while($row = $query->fetch_assoc()){
			$all_arrays[]=$row;
		}
		
		return $all_arrays;
	}

	public function getUsersValidations($id, $status = -1)
	{
		include "connect.php";


		if($status == 0){

			$query = $mysqli->query("SELECT ID, 
											PART_NUMBER, 
											ROUTING_TYPE,
											STATUS
									FROM ges_validations.validations 
									WHERE USER_ID = ".$id."
										AND STATUS = 0");
		}elseif($status == 1){

			$query = $mysqli->query("SELECT v.ID,
											v.PART_NUMBER, 
											v.ROUTING_TYPE,
											v.STATUS,
											v.HAS_ERRORS,
									    	v.DATE_VALIDATED,
											COUNT(CASE WHEN e.DESCRIPTION IS NOT NULL THEN 1 END) as ERROR_COUNT
									FROM ges_validations.validations v
									LEFT JOIN ges_validations.errors e
										ON e.VALIDATION_ID = v.ID
									WHERE v.USER_ID = ".$id."
										AND v.STATUS = 1
									GROUP BY v.ID
									ORDER BY v.DATE_VALIDATED DESC");
		}else{
			$query = $mysqli->query("SELECT ID, 
											PART_NUMBER, 
											ROUTING_TYPE, 
											STATUS, 
											HAS_ERRORS
									FROM ges_validations.validations 
									WHERE USER_ID = ".$id);
		}

		$all_arrays = array();
		while($row = $query->fetch_assoc()){
			$all_arrays[]=$row;
		}
		
		return $all_arrays;
	}

	public function getValidationsWithStatus($status)
	{
		include "connect.php";

		if($status == 0){

			$query = $mysqli->query("SELECT v.PART_NUMBER,  
											v.ROUTING_TYPE, 
											v.STATUS, 
											u.NAME
									 FROM ges_validations.validations v
									 INNER JOIN ges_validations.users u
									 	ON u.ID = v.USER_ID
									 WHERE v.STATUS = 0");
		}elseif($status == 1){

			$query = $mysqli->query("SELECT v.ID,  
											v.PART_NUMBER, 
											v.ROUTING_TYPE,
											v.STATUS,
											v.HAS_ERRORS,
											v.DATE_VALIDATED,
											u.NAME,
											COUNT(CASE WHEN e.DESCRIPTION IS NOT NULL THEN 1 END) as ERROR_COUNT
									FROM ges_validations.validations v
									LEFT JOIN ges_validations.errors e
										ON e.VALIDATION_ID = v.ID
									INNER JOIN ges_validations.users u
										ON u.ID = v.USER_ID
									WHERE v.STATUS = 1
									GROUP BY v.PART_NUMBER, v.ROUTING_TYPE
									ORDER BY v.DATE_VALIDATED DESC");
		}

		$all_arrays = array();
		while($row = $query->fetch_assoc()){
			$all_arrays[]=$row;
		}
		
		return $all_arrays;
	}

	public function getValidationDetails($validation_id)
	{
		include "connect.php";

		$query = $mysqli->query("SELECT PART_NUMBER, 
										ROUTING_TYPE,
										USER_ID
								FROM ges_validations.validations 
								WHERE ID = ".$validation_id);

		$row = $query->fetch_assoc();
		
		return $row;
	}

	public function getPartnumErrors($validation_id)
	{
		include "connect.php";

		$query = $mysqli->query("SELECT ID,
										SEQ_NO,
										DESCRIPTION,
										STATUS,
										DATE_FIXED
								 FROM ges_validations.errors
								 WHERE VALIDATION_ID = '".$validation_id."'");
		$all_arrays = array();
		while($row = $query->fetch_assoc()){
			$all_arrays[]=$row;
		}
		
		return $all_arrays;
	}

	public function getValidator($validation_id)
	{
		include "connect.php";

		$query = $mysqli->query("SELECT u.ID,
										u.NAME
								 FROM ges_validations.validations v
								 INNER JOIN ges_validations.users u
								 	ON u.ID = v.USER_ID
								 WHERE v.ID = ".$validation_id);
		
		$row = $query->fetch_assoc();

		return $row;
	}

	public function getErrorsFromFile()
	{
		include "connect.php";
		
		try {
    
		    // Undefined | Multiple Files | $_FILES Corruption Attack
		    // If this request falls under any of them, treat it invalid.
		    if (
		        !isset($_FILES['upfile']['error']) ||
		        is_array($_FILES['upfile']['error'])
		    ) {
		        throw new RuntimeException('Invalid parameters.');
		    }

		    // Check $_FILES['upfile']['error'] value.
		    switch ($_FILES['upfile']['error']) {
		        case UPLOAD_ERR_OK:
		            break;
		        case UPLOAD_ERR_NO_FILE:
		            throw new RuntimeException('No file sent.');
		        case UPLOAD_ERR_INI_SIZE:
		        case UPLOAD_ERR_FORM_SIZE:
		            throw new RuntimeException('Exceeded filesize limit.');
		        default:
		            throw new RuntimeException('Unknown errors.');
		    }

		    // You should also check filesize here. 
		    if ($_FILES['upfile']['size'] > 1000000) {
		        throw new RuntimeException('Exceeded filesize limit.');
		    }

		    // DO NOT TRUST $_FILES['upfile']['mime'] VALUE !!
		    // Check MIME Type by yourself.
		    /*
		    $finfo = new finfo(FILEINFO_MIME_TYPE);
		    if (false === $ext = array_search(
		        $finfo->file($_FILES['upfile']['tmp_name']),
		        array(
		            'xls' => 'application/vnd.ms-excel'
		        ),
		        true
		    )) {
		        throw new RuntimeException('Invalid file format.');
		    }
			*/
		    // You should name it uniquely.
		    // DO NOT USE $_FILES['upfile']['name'] WITHOUT ANY VALIDATION !!
		    // On this example, obtain safe unique name from its binary data.
		    
		    $file_name = sha1_file($_FILES['upfile']['tmp_name']);

		    if (!move_uploaded_file(
		        $_FILES['upfile']['tmp_name'],
		        sprintf('public/spreadsheets/%s.xls',
		            $file_name
		        )
		    )) {
		        throw new RuntimeException('Failed to move uploaded file.');
		    }
		} catch (RuntimeException $e) {

		    echo $e->getMessage();

		}

		/** Error reporting */
		error_reporting(E_ALL);
		ini_set('display_errors', TRUE); 
		ini_set('display_startup_errors', TRUE); 

		/** Include PHPExcel */
		require_once("include/PHPExcel.php");

		$objPHPExcel = PHPExcel_IOFactory::load("public/spreadsheets/".$file_name.".xls");

		$rows = $objPHPExcel->getActiveSheet()->toArray();

		$errors_array = [];
		for($i = 1; $i <= count($rows) - 1; $i++){
			$error_desc = '';
			for($j = 2; $j <= count($rows[$i]) - 1; $j++){
				if($rows[$i][$j] <> ''){
					$error_desc .= $rows[$i][$j] . ": ";
				}
			}
			if($error_desc <> ''){
				$error = [];
				array_push($error, $rows[$i][1]);
				array_push($error, rtrim($error_desc,": "));
				array_push($errors_array, $error);
			}
		}

		return $errors_array;
	}

	public function generateExcelReport()
	{
		include "connect.php";

		$errors = $this->getAllErrors();


		/** Error reporting */
		error_reporting(E_ALL);
		ini_set('display_errors', TRUE); 
		ini_set('display_startup_errors', TRUE); 

		/** Include PHPExcel */
		require_once("include/PHPExcel.php");

		// Create new PHPExcel object
		$objPHPExcel = new PHPExcel();

		// Set document properties
		$objPHPExcel->getProperties()->setCreator("GES Validation")
									 ->setLastModifiedBy("GES Validation")
									 ->setTitle("GES Validation - Errors Found")
									 ->setSubject("GES Validation - Errors Found")
									 ->setDescription("GES Validation - Errors Found");

		$objPHPExcel->setActiveSheetIndex(0)
		            ->setCellValue('A1', 'Part Number')
		            ->setCellValue('B1', 'Routing Type')
		            ->setCellValue('C1', 'Seq No')
		            ->setCellValue('D1', 'Error Description')
		            //->setCellValue('E1', 'Status')
		            ->setCellValue('E1', 'Date Validated')
		            ->setCellValue('F1', 'Validator');

		$row_number = 2;
		foreach($errors as $error){
			$objPHPExcel->setActiveSheetIndex(0)
		            ->setCellValue('A'.$row_number, $error['PART_NUMBER'])
		            ->setCellValue('B'.$row_number, $error['ROUTING_TYPE'])
		            ->setCellValue('C'.$row_number, $error['SEQ_NO'])
		            ->setCellValue('D'.$row_number, $error['DESCRIPTION'])
		            //->setCellValue('E'.$row_number, $error['STATUS'] == 0 ? 'Unfixed' : 'Fixed')
		            ->setCellValue('E'.$row_number, $error['DATE_VALIDATED'])
		            ->setCellValue('F'.$row_number, $error['NAME']);

		    $row_number++;
		}

		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(90);
		//$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
		$objPHPExcel->getActiveSheet()->setTitle('Errors Found');
		$objPHPExcel->setActiveSheetIndex(0);

		// Redirect output to a client’s web browser (Excel5)
		header('Content-Type: application/vnd.ms-excel');
		header('Content-Disposition: attachment;filename="GES Validations - Errors Found.xls"');
		header('Cache-Control: max-age=0');
		// If you're serving to IE 9, then the following may be needed
		header('Cache-Control: max-age=1');

		// If you're serving to IE over SSL, then the following may be needed
		header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
		header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
		header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
		header ('Pragma: public'); // HTTP/1.0

		$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
		$objWriter->save('php://output');
		exit;
	}

	public function validateNoErrors()
	{
		include "connect.php";

		$query = "UPDATE ges_validations.validations
				  SET 
					  STATUS = 1,
					  HAS_ERRORS = 0,
					  DATE_VALIDATED = '".date("Y-m-d")."'
				   WHERE
					  ID = '".$_POST['validation_id']."'";
		$que = $mysqli->query($query);	
			
		if(!$que)
		{
			echo "ERROR: ".mysqli_error($mysqli);
			echo $query;
		}else{
			$this->logActivity($_SESSION['USER']['ID'], "Validated Part Number: ".$_POST['part_number']." (".$_POST['routing_type'].") with No Errors.");
		}
	}

	public function validateWithErrors()
	{
		include "connect.php";

		// update validation status
		$query = "UPDATE ges_validations.validations
				  SET 
					  STATUS = 1,
					  HAS_ERRORS = 1,
					  DATE_VALIDATED = '".date("Y-m-d")."'
				   WHERE
					  ID = ".$_POST['validation_id'];
		$que = $mysqli->query($query);	
			
		if(!$que)
		{
			echo "ERROR: ".mysqli_error($mysqli);
			echo $query;
		}

		//insert errors
		$stmt = $mysqli->prepare("INSERT INTO ges_validations.errors
								(
									VALIDATION_ID,
									SEQ_NO,
									DESCRIPTION,
									STATUS
								)
								VALUES(?, ?, ?, 0)");

		for($i = 0; $i <= count($_POST['errors']) - 1; $i++){
			$stmt->bind_param("iis", $_POST['validation_id'], $_POST['seq_nos'][$i], $_POST['errors'][$i]);
			$stmt->execute();
			$stmt->free_result();
		}

		$this->logActivity($_SESSION['USER']['ID'], "Validated Part Number: ".$_POST['part_number']." (".$_POST['routing_type'].") with ".count($_POST['errors'])." Errors.");

		$stmt->close();
	}

	public function changeErrorStatus($error_id, $new_status)
	{
		include "connect.php";

		$query = "UPDATE ges_validations.errors
				  SET 
					  STATUS = ".$new_status.",
					  DATE_FIXED = '".date("Y-m-d")."'
				   WHERE
					  ID = ".$error_id;

		$que = $mysqli->query($query);	
			
		if(!$que)
		{
			echo "ERROR: ".mysqli_error($mysqli);
			echo $query;
		}
	}

	public function updateValidation()
	{
		include "connect.php";

		$stmt = $mysqli->prepare("UPDATE ges_validations.validations
				  				  SET 
								  	PART_NUMBER = ?,
								  	ROUTING_TYPE = ?
							   	  WHERE
							   	  	ID = ".$_POST['validation_id']);

		$stmt->bind_param("ss", $_POST['edit_part_number'], $_POST['edit_routing_type']);
		$stmt->execute();
		$stmt->close();

		$this->logActivity($_SESSION['USER']['ID'], "Edited Part Number: ".$_POST['edit_part_number']." (".$_POST['edit_routing_type'].")");
	}

	public function updateError()
	{
		include "connect.php";

		$query = "UPDATE ges_validations.errors
				  SET DESCRIPTION = '".addslashes($_POST['edit_description'])."',
				  	  SEQ_NO = ".$_POST['edit_seq_no']."
				  WHERE
					ID = ".$_POST['error_id'];
		$que = $mysqli->query($query);	
			
		if(!$que)
		{
			echo "ERROR: ".mysqli_error($mysqli);
			echo $query;
		}else{
			$this->logActivity($_SESSION['USER']['ID'], "Edited Error of Part Number: ".$_POST['part_number']." (".$_POST['routing_type'].")");
		}
	}

	public function getErrors($date_start, $date_end)
	{
		include "connect.php";

		$query = $mysqli->query("SELECT 
									v.PART_NUMBER, 
									v.ROUTING_TYPE,
									e.SEQ_NO,
									e.DESCRIPTION,
									u.NAME,
									v.DATE_VALIDATED
								FROM ges_validations.errors e
									INNER JOIN ges_validations.validations v
										ON v.ID = e.VALIDATION_ID
									INNER JOIN ges_validations.users u
										ON v.USER_ID = u.ID
								WHERE v.DATE_VALIDATED BETWEEN '".$date_start."' AND '".$date_end."'
								ORDER BY v.DATE_VALIDATED DESC, v.PART_NUMBER, e.SEQ_NO");

		$all_arrays = array();
		while($row = $query->fetch_assoc()){
			$all_arrays[]=$row;
		}
		
		return $all_arrays;
	}

	public function getAllErrors()
	{
		include "connect.php";

		$query = $mysqli->query("SELECT 
									v.PART_NUMBER, 
									v.ROUTING_TYPE,
									e.SEQ_NO,
									e.DESCRIPTION,
									e.STATUS,
									v.DATE_VALIDATED,
									u.NAME
								FROM ges_validations.errors e
									INNER JOIN ges_validations.validations v
										ON v.ID = e.VALIDATION_ID
									INNER JOIN ges_validations.users u
										ON v.USER_ID = u.ID
								ORDER BY v.DATE_VALIDATED DESC, v.PART_NUMBER, e.SEQ_NO");

		$all_arrays = array();
		while($row = $query->fetch_assoc()){
			$all_arrays[]=$row;
		}
		
		return $all_arrays;
	}

	public function getErrorCount()
	{
		include "connect.php";

		$query = $mysqli->query("SELECT 
									COUNT(e.ID) as OVERALL,
									COUNT(CASE WHEN v.DATE_VALIDATED >= '".date('Y-m')."-01' THEN 1 END) as MONTHLY,
									COUNT(CASE WHEN v.DATE_VALIDATED >= '".date('Y-m-d', strtotime('-6 days'))."' THEN 1 END) as WEEKLY
								FROM ges_validations.errors e
								INNER JOIN ges_validations.validations v
									ON v.ID = e.VALIDATION_ID");

		$row = $query->fetch_assoc();
		
		return $row;
	}

	public function validatePartnum($part_number, $rc_id, $routing_type, $start_setup_no, $end_setup_no)
	{
		include "connect.php";

		$query = "CREATE TEMPORARY TABLE IF NOT EXISTS ges_validations.temp_route_ids AS 
					(
						SELECT 
							PART_NUMBER,
							ROUTING_TYPE,
							CAST(OPERATION_SEQ_NO AS UNSIGNED) AS SEQ_NO,
							OPERATION_CODE,
							GREATEST(SETUP_NO - (? - 1), 0) AS SETUP_NO,
							STEP_TYPE_CODE,
							TOOL_TYPE,
							CASE WHEN TOOL_TYPE = 'SETN' THEN
								REPLACE(TOOLING_PART_NO, SETUP_NO, GREATEST(SETUP_NO - ".($start_setup_no - 1).", 0))
							ELSE
								TOOLING_PART_NO
							END AS TOOLING_PART_NO,
							TOOL_DESCRIPTION
						FROM maxcim_conversion.route_ids
						WHERE PART_NUMBER = ?
							AND ROUTING_TYPE = ?
							AND (
								SETUP_NO BETWEEN ? AND ?
								OR SETUP_NO = 0
							)
					);";

		$stmt = $mysqli->stmt_init();
		if(!$stmt->prepare($query)){
		    print "Failed to prepare statement - ".htmlspecialchars($mysqli->error);
		}else{
		    $stmt->bind_param("issii", $start_setup_no, $part_number, $routing_type, $start_setup_no, $end_setup_no);

		   	$stmt->execute();
			$stmt->free_result();
		}

		$query = "CREATE TEMPORARY TABLE IF NOT EXISTS ges_validations.temp_route_ids2 AS 
					(SELECT * FROM ges_validations.temp_route_ids);";

		$stmt = $mysqli->stmt_init();
		if(!$stmt->prepare($query)){
		    print "Failed to prepare statement - ".htmlspecialchars($mysqli->error);
		}else{
		   	$stmt->execute();
			$stmt->free_result();
		}

		$query = "CREATE TEMPORARY TABLE IF NOT EXISTS ges_validations.validation_results AS  
					(
						SELECT *
							  FROM (
							  		SELECT 
										TRI.PART_NUMBER,
										TRI.SEQ_NO,
										TRI.SETUP_NO,
										TRI.STEP_TYPE_CODE,
										TRI.TOOL_TYPE,
										TRI.TOOLING_PART_NO,
										RIC.TOOLING_PART_NO as TPN2,
										TRI.TOOL_DESCRIPTION,
										CASE WHEN RIC.TOOLING_PART_NO = TRI.TOOLING_PART_NO THEN 'Same'
										ELSE 'Missing' END as REMARKS
									FROM ges_validations.temp_route_ids TRI
									LEFT JOIN ges_validations.route_ids_chino RIC
										ON RIC.PART_NUMBER = TRI.PART_NUMBER
										AND RIC.ROUTING_TYPE = TRI.ROUTING_TYPE
										AND RIC.OPERATION_SEQ_NO = TRI.SEQ_NO
										AND RIC.OPERATION_CODE = TRI.OPERATION_CODE
										AND RIC.SETUP_NO = TRI.SETUP_NO
										AND RIC.STEP_TYPE_CODE = TRI.STEP_TYPE_CODE
										AND RIC.TOOL_TYPE = TRI.TOOL_TYPE
										AND RIC.TOOLING_PART_NO = TRI.TOOLING_PART_NO
										AND RIC.TOOL_DESCRIPTION = TRI.TOOL_DESCRIPTION
										AND RIC.RC_ID = ?

									UNION ALL

									SELECT 
										RIC.PART_NUMBER,
										CAST(RIC.OPERATION_SEQ_NO AS UNSIGNED) AS SEQ_NO,
										RIC.SETUP_NO,
										RIC.STEP_TYPE_CODE,
										RIC.TOOL_TYPE,
										TRI2.TOOLING_PART_NO,
										RIC.TOOLING_PART_NO as TPN2,
										RIC.TOOL_DESCRIPTION,
										CASE WHEN RIC.TOOL_TYPE <> '' THEN 'Added'
										ELSE '' END as REMARKS
									FROM ges_validations.route_ids_chino RIC
									LEFT JOIN ges_validations.temp_route_ids2 TRI2
										ON RIC.PART_NUMBER = TRI2.PART_NUMBER
										AND RIC.ROUTING_TYPE = TRI2.ROUTING_TYPE
										AND RIC.OPERATION_SEQ_NO = TRI2.SEQ_NO
										AND RIC.OPERATION_CODE = TRI2.OPERATION_CODE
										AND RIC.SETUP_NO = TRI2.SETUP_NO
										AND RIC.STEP_TYPE_CODE = TRI2.STEP_TYPE_CODE
										AND RIC.TOOL_TYPE = TRI2.TOOL_TYPE
										AND RIC.TOOLING_PART_NO = TRI2.TOOLING_PART_NO
										AND RIC.TOOL_DESCRIPTION = TRI2.TOOL_DESCRIPTION
									WHERE RIC.PART_NUMBER = ?
										AND TRI2.TOOLING_PART_NO IS NULL
										AND RIC.ROUTING_TYPE = ?
										AND RIC.RC_ID = ?
									) R1
							ORDER BY SEQ_NO, STEP_TYPE_CODE, SETUP_NO, TOOL_TYPE);";

		$stmt = $mysqli->stmt_init();
		if(!$stmt->prepare($query)){
		    print "Failed to prepare statement - ".htmlspecialchars($mysqli->error);
		}else{
		    $stmt->bind_param("issi", $rc_id, $part_number, $routing_type, $rc_id);
		   	$stmt->execute();
		   	$stmt->free_result();
		}

		$query = "CREATE TEMPORARY TABLE IF NOT EXISTS ges_validations.results_missing AS 
					(
						SELECT * 
						FROM ges_validations.validation_results
						WHERE SETUP_NO > 0
							AND REMARKS = 'Missing'
					);";

		$stmt = $mysqli->stmt_init();
		if(!$stmt->prepare($query)){
		    print "Failed to prepare statement - ".htmlspecialchars($mysqli->error);
		}else{
		   	$stmt->execute();
			$stmt->free_result();
		}

		$query = "CREATE TEMPORARY TABLE IF NOT EXISTS ges_validations.results_added AS 
					(
						SELECT * 
						FROM ges_validations.validation_results
						WHERE SETUP_NO = 0
							AND REMARKS = 'Added'
					);";

		$stmt = $mysqli->stmt_init();
		if(!$stmt->prepare($query)){
		    print "Failed to prepare statement - ".htmlspecialchars($mysqli->error);
		}else{
		   	$stmt->execute();
			$stmt->free_result();
		}

		$query = "CREATE TEMPORARY TABLE IF NOT EXISTS ges_validations.setup_numbers AS 
					(
						SELECT STEP_TYPE_CODE, SETUP_NO
						FROM ges_validations.temp_route_ids
					);";

		$stmt = $mysqli->stmt_init();
		if(!$stmt->prepare($query)){
		    print "Failed to prepare statement - ".htmlspecialchars($mysqli->error);
		}else{
		   	$stmt->execute();
			$stmt->free_result();
		}

		$query = "SELECT 
						TTC.PART_NUMBER,
						TTC.SEQ_NO,
						TTC.SETUP_NO,
						TTC.STEP_TYPE_CODE,
						TTC.TOOL_TYPE,
						TTC.TOOLING_PART_NO,
						TTC.TPN2,
						TTC.TOOL_DESCRIPTION,
						CASE WHEN E1.STEP_TYPE_CODE IS NOT NULL THEN
							'Modified'
						ELSE
							TTC.REMARKS
						END
					FROM ges_validations.validation_results TTC
					LEFT JOIN (
						SELECT M1.SEQ_NO, M1.STEP_TYPE_CODE, M1.TOOLING_PART_NO 
						FROM (
							SELECT *
							FROM ges_validations.results_missing RM1
							GROUP BY SEQ_NO, STEP_TYPE_CODE, TOOLING_PART_NO, REMARKS
							HAVING COUNT(SETUP_NO) = (
								SELECT MAX(SETUP_NO) 
								FROM ges_validations.setup_numbers 
								WHERE STEP_TYPE_CODE = RM1.STEP_TYPE_CODE
							) 
							AND (
								COUNT(SETUP_NO) > 1
								OR TOOL_TYPE NOT IN ('H','T','P','L')
							)
						) M1
						INNER JOIN ges_validations.results_added ttc2
						ON ttc2.STEP_TYPE_CODE = M1.STEP_TYPE_CODE
							AND ttc2.TPN2 = M1.TOOLING_PART_NO
							AND ttc2.SEQ_NO = M1.SEQ_NO
					) E1
					ON E1.SEQ_NO = TTC.SEQ_NO
						AND E1.STEP_TYPE_CODE = TTC.STEP_TYPE_CODE
						AND 
							(
								E1.TOOLING_PART_NO = TTC.TOOLING_PART_NO
								OR E1.TOOLING_PART_NO = TTC.TPN2
							);";

		$stmt = $mysqli->stmt_init();
		if(!$stmt->prepare($query)){
		    print "Failed to prepare statement - ".htmlspecialchars($mysqli->error);
		}else{
		   	$stmt->execute();
	        $result = $stmt->get_result();
	        $all_arrays = array();
	        while ($row = $result->fetch_array(MYSQLI_NUM)){
	           $all_arrays[] = $row;
	        }
		}

		$stmt->close();
		$mysqli->close();
		
		return $all_arrays;
	}

	public function validatePartnumDuplicates($part_number, $rc_id, $routing_type)
	{
		include "connect.php";

		$query_str = "SELECT 
						T1.PART_NUMBER,
						T1.SEQ_NO,
						T1.OPERATION_CODE,
						T1.STEP_TYPE_CODE,
						T1.SETUP_NO,
						T1.TOOLING_PART_NO,
						T1.TOOL_TYPE,
						T1.COUNT as MAXCIM_COUNT,
						T2.COUNT as XROTS_COUNT,
						'Duplicate' as REMARKS
					FROM (SELECT 
								RI.PART_NUMBER,
								RI.ROUTING_TYPE,
								CAST(RI.OPERATION_SEQ_NO AS UNSIGNED) AS SEQ_NO,
								RI.SETUP_NO,
								RI.OPERATION_CODE,
								RI.STEP_TYPE_CODE,
								RI.TOOL_TYPE,
								RI.TOOLING_PART_NO,
								COUNT(*) as COUNT
							FROM maxcim_conversion.route_ids RI
							WHERE RI.PART_NUMBER = '".$part_number."'
								AND RI.ROUTING_TYPE = '".$routing_type."'
							GROUP BY RI.OPERATION_SEQ_NO, RI.STEP_TYPE_CODE, RI.SETUP_NO, RI.TOOL_TYPE, RI.TOOLING_PART_NO
						) T1
						INNER JOIN (SELECT 
								RIC.PART_NUMBER,
								RIC.ROUTING_TYPE,
								CAST(RIC.OPERATION_SEQ_NO AS UNSIGNED) AS SEQ_NO,
								RIC.SETUP_NO,
								RIC.OPERATION_CODE,
								RIC.STEP_TYPE_CODE,
								RIC.TOOL_TYPE,
								RIC.TOOLING_PART_NO,
								COUNT(*) as COUNT
							FROM ges_validations.route_ids_chino RIC
							WHERE RIC.PART_NUMBER = '".$part_number."'
								AND RIC.ROUTING_TYPE = '".$routing_type."'
								AND RIC.RC_ID = ".$rc_id."
							GROUP BY RIC.OPERATION_SEQ_NO, RIC.STEP_TYPE_CODE, RIC.SETUP_NO, RIC.TOOL_TYPE, RIC.TOOLING_PART_NO) T2
						ON T2.PART_NUMBER = T1.PART_NUMBER
						AND T2.ROUTING_TYPE = T1.ROUTING_TYPE
						AND T2.SEQ_NO = T1.SEQ_NO
						AND T2.OPERATION_CODE = T1.OPERATION_CODE
						AND T2.STEP_TYPE_CODE = T1.STEP_TYPE_CODE
						AND T2.SETUP_NO = T1.SETUP_NO
						AND T2.TOOL_TYPE = T1.TOOL_TYPE
						AND T2.TOOLING_PART_NO = T1.TOOLING_PART_NO
						AND T2.SEQ_NO = T1.SEQ_NO
					WHERE T1.COUNT > 1 OR T2.COUNT > 1
					ORDER BY T1.SEQ_NO, T1.STEP_TYPE_CODE, T1.SETUP_NO";

		$query = $mysqli->query($query_str);

		$all_arrays = array();
		while($row = $query->fetch_assoc()){
			$all_arrays[]=$row;
		}
		
		return $all_arrays;
	}

	public function validatePartnumOpCode($part_number, $rc_id, $routing_type)
	{
		include "connect.php";

		$query_str = "SELECT DISTINCT
						RI.PART_NUMBER,
						CAST(RI.OPERATION_SEQ_NO AS UNSIGNED) AS SEQ_NO,
						RI.STEP_TYPE_CODE,
					    RI.OPERATION_CODE as MAXCIM_OP_CODE,
					    RIC.OPERATION_CODE as XROTS_OP_CODE,
						CASE WHEN RI.OPERATION_CODE = RIC.OPERATION_CODE THEN 'Same'
							WHEN RI.OPERATION_CODE IN (SELECT OPERATION_CODE
														 FROM ges_validations.route_ids_chino
														 WHERE PART_NUMBER = RI.PART_NUMBER
															AND ROUTING_TYPE = RI.ROUTING_TYPE
															AND STEP_TYPE_CODE = RI.STEP_TYPE_CODE) THEN 'Same'
							ELSE 'Mismatch'
						END as REMARKS
					  FROM maxcim_conversion.route_ids RI
					  INNER JOIN ges_validations.route_ids_chino RIC
						ON RIC.PART_NUMBER = RI.PART_NUMBER
						AND RIC.ROUTING_TYPE = RI.ROUTING_TYPE
						AND RIC.SETUP_NO = RI.SETUP_NO
						AND RIC.STEP_TYPE_CODE = RI.STEP_TYPE_CODE
					  WHERE RI.PART_NUMBER = '".$part_number."'
						AND RI.ROUTING_TYPE = '".$routing_type."'
						AND RIC.RC_ID = ".$rc_id."
					  ORDER BY SEQ_NO, RI.STEP_TYPE_CODE";

		$query = $mysqli->query($query_str);

		$all_arrays = array();
		while($row = $query->fetch_assoc()){
			$all_arrays[]=$row;
		}
		
		return $all_arrays;
	}

	public function validatePartnumOpSeqNo($part_number, $rc_id, $routing_type)
	{
		include "connect.php";

		$query_str = "SELECT 
						RI.PART_NUMBER,
						RI.STEP_TYPE_CODE,
						RI.OPERATION_SEQ_NO as SEQ_NO,
						RI.SETUP_NO,
						RI.TOOLING_PART_NO,
						RI.TOOL_TYPE,
						RI.OPERATION_SEQ_NO as MAXCIM_SEQ_NO,
						RIC.OPERATION_SEQ_NO as XROTS_SEQ_NO,
						'Mismatch'  as REMARKS
					  FROM maxcim_conversion.route_ids RI
					  INNER JOIN ges_validations.route_ids_chino RIC
						ON RIC.PART_NUMBER = RI.PART_NUMBER
						AND RIC.ROUTING_TYPE = RI.ROUTING_TYPE
						AND RIC.OPERATION_CODE = RI.OPERATION_CODE
						AND RIC.SETUP_NO = RI.SETUP_NO
						AND RIC.STEP_TYPE_CODE = RI.STEP_TYPE_CODE
						AND RIC.TOOL_TYPE = RI.TOOL_TYPE
						AND RIC.TOOLING_PART_NO = RI.TOOLING_PART_NO
					  WHERE RI.PART_NUMBER = '".$part_number."'
						AND RI.ROUTING_TYPE = '".$routing_type."'
						AND RIC.RC_ID = ".$rc_id."
						AND RIC.OPERATION_SEQ_NO <> RI.OPERATION_SEQ_NO
						AND RIC.OPERATION_SEQ_NO NOT IN (SELECT OPERATION_SEQ_NO
														 FROM maxcim_conversion.route_ids
														 WHERE PART_NUMBER = RI.PART_NUMBER
															AND ROUTING_TYPE = RI.ROUTING_TYPE
															AND OPERATION_CODE = RI.OPERATION_CODE
															AND TOOL_TYPE = RI.TOOL_TYPE)
						AND RI.OPERATION_SEQ_NO NOT IN (SELECT OPERATION_SEQ_NO
														 FROM ges_validations.route_ids_chino
														 WHERE PART_NUMBER = RI.PART_NUMBER
															AND ROUTING_TYPE = RI.ROUTING_TYPE
															AND OPERATION_CODE = RI.OPERATION_CODE
															AND TOOL_TYPE = RI.TOOL_TYPE
															AND RC_ID = ".$rc_id.")";

		$query = $mysqli->query($query_str);

		$all_arrays = array();
		while($row = $query->fetch_assoc()){
			$all_arrays[]=$row;
		}
		
		return $all_arrays;
	}

	public function deleteError($id)
	{
		include "connect.php";

		$query = "DELETE
				  FROM ges_validations.errors
				  WHERE ID =".$id;
		$que = $mysqli->query($query);	
			
		if(!$que)
		{
			echo "ERROR: ".mysqli_error($mysqli);
			echo $query;
		}else{
			$this->logActivity($_SESSION['USER']['ID'], "Deleted an Error on Part Number: ".$_POST['part_number']." (".$_POST['routing_type'].")");
		}
	}

	public function deleteValidation($id)
	{
		include "connect.php";

		// Delete errors of the validation
		$query = "DELETE
				  FROM ges_validations.errors
				  WHERE VALIDATION_ID =".$id;
		$que = $mysqli->query($query);	
			
		if(!$que)
		{
			echo "ERROR: ".mysqli_error($mysqli);
			echo $query;
		}else{

			// Delete the validation
			$query2 = "DELETE
					  FROM ges_validations.validations
					  WHERE ID =".$id;
			$que2 = $mysqli->query($query2);

			if(!$que2)
			{
				echo "ERROR: ".mysqli_error($mysqli);
				echo $query2;
			}else{
				$this->logActivity($_SESSION['USER']['ID'], "Deleted Validation of Part Number: ".$_POST['part_number']." (".$_POST['routing_type'].")");
			}
		}	
	}

	public function deleteUserValidations($user_id, $type = -1)
	{
		include "connect.php";

		if($type == 0){	// Delete On Queue Validations
			$query = "DELETE
					   FROM ges_validations.validations
					   WHERE USER_ID = ".$user_id."
					   	  AND STATUS = 0";

			$que = $mysqli->query($query);

			if(!$que)
			{
				echo "ERROR: ".mysqli_error($mysqli);
				echo $query;
			}

		}elseif($type == 1){	// Delete Validated without Errors
			$query = "DELETE
					   FROM ges_validations.validations
					   WHERE USER_ID = ".$user_id."
					   	  AND STATUS = 1
					   	  AND HAS_ERRORS = 0";

			$que = $mysqli->query($query);	
			
			if(!$que)
			{
				echo "ERROR: ".mysqli_error($mysqli);
				echo $query;
			}

		}elseif($type == 2){	// Delete Validated with Errors

			$query = "DELETE
					  FROM ges_validations.errors
					  WHERE VALIDATION_ID IN (
					  	SELECT ID
					  	FROM ges_validations.validations
					  	WHERE USER_ID = ".$user_id."
					  		AND STATUS = 1
					  		AND HAS_ERRORS = 1
					  )";

			$query2 = "DELETE
					   FROM ges_validations.validations
					   WHERE USER_ID = ".$user_id."
					   	  AND STATUS = 1
					   	  AND HAS_ERRORS = 1";

			$que = $mysqli->query($query);	
			
			if(!$que)
			{
				echo "ERROR: ".mysqli_error($mysqli);
				echo $query;
			}else{

				$que2 = $mysqli->query($query2);	
				
				if(!$que2)
				{
					echo "ERROR: ".mysqli_error($mysqli);
					echo $query2;
				}
			}

		}elseif($type == -1){	// Delete all User Validations

			$query = "DELETE
					  FROM ges_validations.errors
					  WHERE VALIDATION_ID IN (
					  	SELECT ID
					  	FROM ges_validations.validations
					  	WHERE USER_ID = ".$user_id."
					  )";

			$query2 = "DELETE
					   FROM ges_validations.validations
					   WHERE USER_ID = ".$user_id;

			$que = $mysqli->query($query);	
			
			if(!$que)
			{
				echo "ERROR: ".mysqli_error($mysqli);
				echo $query;
			}else{

				$que2 = $mysqli->query($query2);	
				
				if(!$que2)
				{
					echo "ERROR: ".mysqli_error($mysqli);
					echo $query2;
				}
			}
		}
	}

	public function login($username, $password)
	{
		include "connect.php";

		$query = $mysqli->query("SELECT ID, NAME, USERNAME, PASSWORD
								FROM ges_validations.users
								WHERE USERNAME = '".addslashes($username)."'");
		$row = $query->fetch_assoc();
		
		if(count($row) > 0){
			if(password_verify($password, $row['PASSWORD'])){
				$this->logActivity($row['ID'], "Login");
				unset($row['PASSWORD']);
				return $row;
			}else{
				return array();
			}
		}

		
	}

	public function logActivity($user_id, $log_desc)
	{
		include "connect.php";

		$mysqli->query("INSERT INTO ges_validations.activities 
						(
							USER_ID,
							ACTIVITY_DESC,
							LOG_DATETIME
						)
						VALUES 
						(
							".$user_id.",
							'".$log_desc."',
							'".date("Y-m-d H:i:s")."'
						)");
	}

	public function getActivities()
	{
		include "connect.php";

		$query_str = "SELECT u.NAME,
							 a.ACTIVITY_DESC,
							 a.LOG_DATETIME
					  	FROM ges_validations.activities a
							INNER JOIN ges_validations.users u
							ON u.id = a.user_id
						ORDER BY a.LOG_DATETIME DESC";

		$query = $mysqli->query($query_str);

		$all_arrays = array();
		while($row = $query->fetch_assoc()){
			$all_arrays[]=$row;
		}
		
		return $all_arrays;
	}

	public function changePassword($oldPassword, $newPassword, $userID){
		include "connect.php";

		$success = false;
		$query = $mysqli->query("SELECT PASSWORD
								FROM ges_validations.users
								WHERE ID = ".$userID);
		$row = $query->fetch_assoc();
		
		if(count($row) > 0){
			if(password_verify($oldPassword, $row['PASSWORD'])){
				$stmt = $mysqli->prepare("UPDATE ges_validations.users
								  SET PASSWORD = ?
								  WHERE ID = ".$userID);

				$newPW = password_hash($newPassword, PASSWORD_DEFAULT);
				$stmt->bind_param("s", $newPW);
				$stmt->execute();
				$stmt->close();

				$success = true;
			}
		}

		return $success;
	}

	public function changeUsername($newUsername, $userID){
		include "connect.php";

		$stmt = $mysqli->prepare("UPDATE ges_validations.users
								  SET USERNAME = ?
								  WHERE ID = ".$userID);
		
		$stmt->bind_param("s", $newUsername);
		$stmt->execute();
		$stmt->close();
	}

	public function getDuplicateToolTypes($part_number, $rc_id)
	{
		include "connect.php";

		$query = "SELECT 
						VXROTS.PART_NUMBER,
						VXROTS.OPERATION_SEQ_NO,
						VXROTS.SETUP_NO,
						VXROTS.OPERATION_CODE,
						VXROTS.STEP_TYPE_NAME,
						VXROTS.TOOL_TYPE,
						VXROTS.TOOLING_PART_NO,
						VXROTS.TOOL_DESCRIPTION
				FROM route_builder.v_xrots VXROTS
				INNER JOIN
					(
						SELECT *
						FROM route_builder.v_xrots
						WHERE PART_NUMBER = ?
							AND RC_ID = ?
							AND STEP_TYPE_NAME NOT IN (
													SELECT STEP_TYPE_CODE
													FROM maxcim_conversion.step_types_to_convert
													WHERE STEP_TYPE_CATEGORY = 'ATE'
														AND TO_CONVERT = 1
												)
						GROUP BY OPERATION_SEQ_NO, STEP_TYPE_NAME, SETUP_NO, TOOL_TYPE
						HAVING COUNT(*) > 1
					) DUPS
					ON DUPS.PART_NUMBER = VXROTS.PART_NUMBER
					AND DUPS.RC_ID = VXROTS.RC_ID
					AND DUPS.OPERATION_SEQ_NO =VXROTS.OPERATION_SEQ_NO
					AND DUPS.STEP_TYPE_NAME =VXROTS.STEP_TYPE_NAME
					AND DUPS.SETUP_NO = VXROTS.SETUP_NO
					AND DUPS.TOOL_TYPE =VXROTS.TOOL_TYPE;";

		$stmt = $mysqli_testweb2->stmt_init();
		if(!$stmt->prepare($query)){
		    print "Failed to prepare statement - ".htmlspecialchars($mysqli_testweb2->error);
		}else{
		    $stmt->bind_param("si", $part_number, $rc_id);
		   	$stmt->execute();
	        $result = $stmt->get_result();

		    $all_arrays = array();
	        while ($row = $result->fetch_array(MYSQLI_NUM)){
	           $all_arrays[] = $row;
	        }
		}

		$stmt->close();
		$mysqli_testweb2->close();
		
		return $all_arrays;
	}
}

?>