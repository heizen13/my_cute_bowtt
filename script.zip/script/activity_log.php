<?php
    require_once("include/session.php");

    $activities = $ges->getActivities();
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>GES Validation</title>

        <!-- Styles -->
        <link href="public/css/bootstrap.min.css" rel="stylesheet">
        <link href="public/css/dataTables.bootstrap.min.css" rel="stylesheet">
        <link href="public/css/ges.css" rel="stylesheet">
        <link href="public/css/font-awesome.css" rel="stylesheet">

        <!-- JavaScripts -->
        <script src="public/js/jquery.min.js"></script>
        <script src="public/js/jquery.dataTables.js"></script>

        <style>
            table>tbody>tr>td {
                font-size: 12px;
            }
        </style>
    </head>
    <body>

        <?php require_once("layouts/navbar.php"); ?>

        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-2">
                    <h3 class="page-header">
                        Activity Log
                    </h3>
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <table class="table table-hover table-bordered" id="activities-table" data-order='[[ 2, "desc" ]]' width="100%">
                                <thead>    
                                    <tr>
                                        <th class="col-md-2">Name</th>
                                        <th>Activity</th>
                                        <th class="col-md-2">Datetime</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        foreach($activities as $activity){
                                            echo "<tr>";
                                            echo "<td>".$activity['NAME']."</td>";
                                            echo "<td>".$activity['ACTIVITY_DESC']."</td>";
                                            echo "<td>".$activity['LOG_DATETIME']."</td>";
                                            echo "</tr>";
                                         }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="public/js/bootstrap.min.js"></script>
        <script src="public/js/dataTables.bootstrap.min.js"></script>
        <script>
            $(document).ready( function () {
                $('#activities-table').DataTable({
                    "lengthMenu": [[20, 50, -1],[20, 50, 'All']],
                    "pagingType": "simple"
                });
            });
        </script>
    </body>
</html>