<?php
	require_once('include/pdf.php');
	require_once("include/ges.php");

    $ges = new GES();

    // Retrieve Data
	$overall_data = $ges->getOverallStats();
	$monthly_data = $ges->getStats(date('Y-m')."-01",date('Y-m-d'));
	$weekly_data = $ges->getStats(date('Y-m-d', strtotime('-6 days')),date('Y-m-d'));
	$weekly_errors = $ges->getErrors(date('Y-m-d', strtotime('-6 days')),date('Y-m-d'));


	// Create PDF
	$pdf = new PDF();
	$header = array('Validator', 'Without Errors', 'With Errors', 'Total Validations');
	$pdf->SetFont('Arial','',12);
	$pdf->AddPage();
	$pdf->ValidationTable("Weekly Statistics (".date('m/d/Y', strtotime('-6 days'))." - ".date('m/d/Y').")", $header, $weekly_data);
	$pdf->ValidationTable("Monthly Statistics (".date('m')."/01/".date('Y')." - ".date('m/d/Y').")", $header, $monthly_data);
	$pdf->ValidationTable("Overall Statistics", $header, $overall_data);

	$header = array('', 'Part Number', 'RT', 'Seq#', 'Error Description', 'Validator', 'Date Validated');
	$pdf->ErrorsTable("Errors Found (".date('m/d/Y', strtotime('-6 days'))." - ".date('m/d/Y').")", $header, $weekly_errors);

	$pdf->Output();
?>