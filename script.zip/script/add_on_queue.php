
<div class="panel-body">
    <div class="row">
        <div class="col-md-2 col-md-offset-10">
            <a href="#" data-toggle="modal" data-target="#addOnQueue"  class="btn btn-success btn-md">
                Add On Queue
            </a>
            <div id="addOnQueue" class="modal fade" role="dialog">
                <div class="modal-dialog">     
                    <div class="modal-content">
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <h4 class="page-header">Add On Queue Validation <button type="button" class="close" data-dismiss="modal">&times;</button></h4>
                                    <div class="panel-body">
                                        <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                                            <div class="form-group">
                                                <label class="col-md-3 control-label"> Validator </label>
                                                <div class="col-md-7">
                                                    <input type="text" class="form-control" <?php echo "value='".$_SESSION['USER']['NAME']."'"; ?> disabled>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-3 control-label"> Part Number </label>
                                                <div class="col-md-7">
                                                    <textarea class="form-control" name="part_num" placeholder="Multiple Part Numbers must be separated by commas. Example: '87-00032+050,87-0075S+CA5'" rows="4"></textarea>
            
                                                </div>
                                            </div>

                                            <div class="form-group">
                                                <label class="col-md-3 control-label"> Routing Type </label>
                                                <div class="col-md-2">
                                                    <input type="text" class="form-control" name="routing_type" maxlength="1" required>
                                                </div>
                                            </div>

                                            <input type="hidden" name="add_on_queue" value="1">
                                            <input type="hidden" name="user_id" <?php echo "value='".$_SESSION['USER']['ID']."'"; ?>>

                                            <div class="form-group">
                                                <div class="col-md-2 col-md-offset-3">
                                                    <button type="submit" class="btn btn-primary" onclick="return confirm('Are you sure?')";>
                                                        Submit
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>