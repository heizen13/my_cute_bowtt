<?php
    require_once("include/session.php");

    if(isset($_POST['PART_NUM']) && isset($_POST['RC_ID']) && isset($_POST['ROUTING_TYPE']) ){
        $part_num = $_POST['PART_NUM'];
        $rc_id = $_POST['RC_ID'];
        $routing_type = $_POST['ROUTING_TYPE'];
        $process_type =  $_POST['PROCESS_TYPE'];

        $start_setup_no = empty($_POST['START_SETUP_NO']) ? 1 : $_POST['START_SETUP_NO'];
        $end_setup_no = empty($_POST['END_SETUP_NO']) ? 99 : $_POST['END_SETUP_NO'];
        $show_optional_fields = !empty($_POST['START_SETUP_NO']) || !empty($_POST['END_SETUP_NO']) || $process_type <> 1;

        $xrots_details = $ges->getPartNumDetails2($part_num, $rc_id, $routing_type, $process_type);

        if($process_type != 2){
            $maxcim_details = $ges->getPartNumDetails($part_num, $routing_type, $start_setup_no, $end_setup_no);
            $validate_results = $ges->validatePartnum($part_num, $rc_id, $routing_type, $start_setup_no, $end_setup_no);
            $duplicate_results = $ges->validatePartnumDuplicates($part_num, $rc_id, $routing_type);
            $opcode_results = $ges->validatePartnumOpCode($part_num, $rc_id, $routing_type);
            $seqno_results = $ges->validatePartnumOpSeqNo($part_num, $rc_id, $routing_type);
        }
    }elseif(isset($_GET['PART_NUM']) && isset($_GET['RC_ID']) && isset($_GET['ROUTING_TYPE'])){
        $part_num = $_GET['PART_NUM'];
        $rc_id = intval($_GET['RC_ID']);
        $routing_type = $_GET['ROUTING_TYPE'];
        $process_type =  1;
        
        $start_setup_no = 1;
        $end_setup_no = 99;
        $show_optional_fields = false;

        $xrots_details = $ges->getPartNumDetails2($part_num, $rc_id, $routing_type, $process_type);
        $maxcim_details = $ges->getPartNumDetails($part_num, $routing_type, $start_setup_no, $end_setup_no);
        $validate_results = $ges->validatePartnum($part_num, $rc_id, $routing_type, $start_setup_no, $end_setup_no);
        $duplicate_results = $ges->validatePartnumDuplicates($part_num, $rc_id, $routing_type);
        $opcode_results = $ges->validatePartnumOpCode($part_num, $rc_id, $routing_type);
        $seqno_results = $ges->validatePartnumOpSeqNo($part_num, $rc_id, $routing_type);
    }

    $ERROR_STRINGS = ["Missing", "Added"];
?>     

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>GES Validation</title>

        <!-- Styles -->
        <link href="public/css/bootstrap.min.css" rel="stylesheet">
        <link href="public/css/dataTables.bootstrap.min.css" rel="stylesheet" >
        <link href="public/css/ges.css" rel="stylesheet" >

        <!-- JavaScripts -->
        <script src="public/js/jquery.min.js"></script>
        <script src="public/js/jquery.dataTables.js"></script>
        <script src="public/js/ges.js"></script>
    </head>
    <body>

        <?php require_once("layouts/navbar.php"); ?>

        <div class="container">
            <div class="row">
                <h4 class="page-header">Part Number Search</h4>
                <div class="panel">
                    <div class="panel-body">
                        <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                            <div class="flex-container">
                                <div class="required-fields">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label"> Part Number </label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" name="PART_NUM" <?php if(isset($_POST['PART_NUM'])) echo "value='".$_POST['PART_NUM']."'"; ?> required>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label class="col-md-3 control-label"> RC ID </label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" name="RC_ID" <?php if(isset($_POST['RC_ID'])) echo "value='".$_POST['RC_ID']."'"; ?> required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label class="col-md-3 control-label"> Routing Type </label>
                                        <div class="col-md-4">
                                            <input type="text" class="form-control" name="ROUTING_TYPE" <?php if(isset($_POST['ROUTING_TYPE'])) echo "value='".$_POST['ROUTING_TYPE']."'"; ?> maxlength="1" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="col-md-3 col-md-offset-3">
                                            <button type="submit" class="btn btn-primary">
                                                Search
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="optional-fields-panel">
                                    <div id="optional-fields-label">
                                        <a href="#"><?php if(!isset($show_optional_fields) || !$show_optional_fields) echo "Show Additional Fields"; else echo "Hide Additional Fields"; ?></a>
                                    </div>
                                    <div id="optional-fields">
                                        <div id="optional-fields-radio" <?php if(!isset($show_optional_fields) || !$show_optional_fields) echo "class='hidden-fields'"; ?> >
                                            <div class="radio">
                                                <label class="col-md-12">
                                                    <input type="radio" value="1" name="PROCESS_TYPE" <?php if(!isset($process_type) || $process_type == 1) echo "checked" ?> >Insert and Validate
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label class="col-md-12">
                                                    <input type="radio" value="2" name="PROCESS_TYPE" <?php if(isset($process_type) && $process_type == 2) echo "checked" ?> >Insert Only
                                                </label>
                                            </div>
                                            <div class="radio">
                                                <label class="col-md-12">
                                                    <input type="radio" value="3" name="PROCESS_TYPE" <?php if(isset($process_type) && $process_type == 3) echo "checked" ?> >Validate Only
                                                </label>
                                            </div>
                                        </div>
                                        <div id="optional-fields-setup-no" <?php if(!isset($show_optional_fields) || !$show_optional_fields) echo "class='hidden-fields'"; ?> >
                                            <div class="form-group">
                                                <label class="col-md-5 control-label"> Start Setup No </label>
                                                <div class="col-md-5">
                                                    <input type="number" class="form-control" name="START_SETUP_NO" <?php if(isset($_POST['START_SETUP_NO'])) echo "value='".$_POST['START_SETUP_NO']."'"; ?> min="1">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label class="col-md-5 control-label"> End Setup No </label>
                                                <div class="col-md-5">
                                                    <input type="number" class="form-control" name="END_SETUP_NO" <?php if(isset($_POST['END_SETUP_NO'])) echo "value='".$_POST['END_SETUP_NO']."'"; ?> min="1">
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="field-info col-md-8 col-md-offset-2">
                                                    *MaxCIM Tooling setup numbers to validate. Setup 0 is included by default.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-body">
                        <h4 class="page-header">Source Database <div class="pull-right">Converted Database</div></h4>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="panel panel-default">
                                    <div class="panel-body">  
                                        <table class="table table-hover table-bordered table-results" id="old-table" width="100%">
                                            <thead>    
                                                <tr>
                                                    <th>Seq No</th>
                                                    <th>Setup No</th>
                                                    <th>Operation Code</th>
                                                    <th>Step Type Code</th>
                                                    <th>Tool Type</th>
                                                    <th>Tooling Part No</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    if(isset($maxcim_details) && count($maxcim_details) > 0){
                                                        foreach($maxcim_details as $values){
                                                            echo "<tr>";
                                                            foreach($values as $value){
                                                                echo "<td>".$value."</td>";
                                                            }
                                                            echo "</tr>";
                                                        }
                                                    }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="panel panel-default">
                                    <div class="panel-body">  
                                        <table class="table table-hover table-bordered table-results" id="new-table" width="100%">
                                            <thead>    
                                                <tr>
                                                    <th>Seq No</th>
                                                    <th>Setup No</th>
                                                    <th>Operation Code</th>
                                                    <th>Step Type Code</th>
                                                    <th>Tool Type</th>
                                                    <th>Tooling Part No</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    if(isset($xrots_details) && count($xrots_details) > 0){
                                                        foreach($xrots_details as $values){
                                                            echo "<tr>";
                                                            echo "<td>".$values['OPERATION_SEQ_NO']."</td>";
                                                            echo "<td>".$values['SETUP_NO']."</td>";
                                                            echo "<td>".$values['OPERATION_CODE']."</td>";
                                                            echo "<td>".$values['STEP_TYPE_NAME']."</td>";
                                                            echo "<td>".$values['TOOL_TYPE']."</td>";
                                                            echo "<td>".$values['TOOLING_PART_NO']."</td>";
                                                            echo "</tr>";
                                                        }
                                                    }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="panel-group">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title">
                                                <a data-toggle="collapse" href="#collapse1">
                                                    <h4>Part Number Validation</h4>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="collapse1" class="panel-collapse collapse in">
                                            <div class="panel-body">  
                                                <table class="table table-hover table-bordered table-results" id="validate-table" width="100%">
                                                    <thead>    
                                                        <tr>
                                                            <th>Seq No</th>
                                                            <th>Setup No</th>
                                                            <th>Step Type Code</th>
                                                            <th>Tool Type</th>
                                                            <th>Tooling Part No (1)</th>
                                                            <th>Tooling Part No (2)</th>
                                                            <th>Tool Description</th>
                                                            <th>Remarks</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                            if(isset($validate_results) && count($validate_results) > 0){
                                                                foreach($validate_results as $values){
                                                                    
                                                                    if($values[2] % 2 == 0){
                                                                        echo "<tr class='toggle-row'>";
                                                                    }else{
                                                                        echo "<tr class='row-odd toggle-row'>";
                                                                    }
                                                                    echo "<td>".$values[1]."</td>";
                                                                    echo "<td>".$values[2]."</td>";
                                                                    echo "<td>".$values[3]."</td>";
                                                                    echo "<td>".$values[4]."</td>";
                                                                    echo "<td>".$values[5]."</td>";
                                                                    echo "<td>".$values[6]."</td>";
                                                                    echo "<td>".$values[7]."</td>";

                                                                    if($values[8] === "Same"){
                                                                        echo "<td class='text-success'>".$values[8]."</td>";
                                                                    }elseif(in_array($values[8], $ERROR_STRINGS)){
                                                                        echo "<td class='text-danger'>".$values[8]."</td>";
                                                                    }elseif($values[8] === "Modified"){
                                                                        echo "<td class='text-primary'>".$values[8]."</td>";
                                                                    }else{
                                                                        echo "<td>".$values[8]."</td>";
                                                                    }
                                                                    echo "</tr>";
                                                                }
                                                            }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="panel-group">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title">
                                                <a data-toggle="collapse" href="#collapse2">
                                                    <h4>Duplicates</h4>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="collapse2" class="panel-collapse collapse in">
                                        <div class="panel-body">  
                                            <table class="table table-hover table-bordered table-results" id="duplicate-table" width="100%">
                                                <thead>    
                                                    <tr>
                                                        <th>Part Number</th>
                                                        <th>Seq No</th>
                                                        <th>Op Code</th>
                                                        <th>Step Type Code</th>
                                                        <th>Setup No</th>
                                                        <th>Tooling Part No</th>
                                                        <th>Tool Type</th>
                                                        <th>MAXCIM Count</th>
                                                        <th>XROTS Count</th>
                                                        <th>Remark</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                        if(isset($duplicate_results) && count($duplicate_results) > 0){
                                                            foreach($duplicate_results as $values){
                                                                echo "<tr>";
                                                                foreach($values as $value){          
                                                                    echo "<td>".$value."</td>";
                                                                }
                                                                echo "</tr>";
                                                            }
                                                        }
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="panel-group">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title">
                                                <a data-toggle="collapse" href="#collapse3">
                                                    <h4>Operation Code Mismatch</h4>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="collapse3" class="panel-collapse collapse in">
                                            <div class="panel-body">
                                                <table class="table table-hover table-bordered table-results" id="duplicate-table" width="100%">
                                                    <thead>    
                                                        <tr>
                                                            <th>Part Number</th>
                                                            <th>Seq No</th>
                                                            <th>Step Type Code</th>
                                                            <th>MAXCIM Op Code</th>
                                                            <th>XROTS Op Code</th>
                                                            <th>Remarks</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                            if(isset($opcode_results) && count($opcode_results) > 0){
                                                                foreach($opcode_results as $values){
                                                                    echo "<tr>";
                                                                    foreach($values as $value){          
                                                                        if($value == "Same"){
                                                                            echo "<td class='text-success'>".$value."</td>";
                                                                        }elseif($value == "Mismatch"){
                                                                            echo "<td class='text-danger'>".$value."</td>";
                                                                        }else{
                                                                            echo "<td>".$value."</td>";
                                                                        }
                                                                    }
                                                                    echo "</tr>";
                                                                }
                                                            }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-12">
                                <div class="panel-group">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title">
                                                <a data-toggle="collapse" href="#collapse4">
                                                    <h4>Operation Sequence Number Mismatch</h4>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="collapse4" class="panel-collapse collapse in">
                                            <div class="panel-body">
                                                <table class="table table-hover table-bordered table-results" id="seqno-table" width="100%">
                                                    <thead>    
                                                        <tr>
                                                            <th>Part Number</th>
                                                            <th>Seq No</th>
                                                            <th>Step Type Code</th>
                                                            <th>Setup No</th>
                                                            <th>Tooling Part No</th>
                                                            <th>Tool Type</th>
                                                            <th>MAXCIM Seq No</th>
                                                            <th>XROTS Seq No</th>
                                                            <th>Remarks</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                            if(isset($seqno_results) && count($seqno_results) > 0){
                                                                foreach($seqno_results as $values){
                                                                    echo "<tr>";
                                                                    foreach($values as $value){          
                                                                        if($value == "Same"){
                                                                            echo "<td class='text-success'>".$value."</td>";
                                                                        }elseif($value == "Mismatch"){
                                                                            echo "<td class='text-danger'>".$value."</td>";
                                                                        }else{
                                                                            echo "<td>".$value."</td>";
                                                                        }
                                                                    }
                                                                    echo "</tr>";
                                                                }
                                                            }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="panel-group">
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title">
                                                <a data-toggle="collapse" href="#collapse5">
                                                    <h4>Consolidated Errors</h4>
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="collapse5" class="panel-collapse collapse in">
                                            <div class="panel-body">
                                                <table class="table table-hover table-bordered table-results" id="consolidated-table" width="100%">
                                                    <thead>    
                                                        <tr>
                                                            <th>Part Number</th>
                                                            <th>Seq No</th>
                                                            <th>Category</th>
                                                            <th></th>
                                                            <th></th>
                                                            <th></th>
                                                            <th></th>
                                                            <th></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                             if(isset($validate_results) && count($validate_results) > 0){
                                                                foreach($validate_results as $values){
                                                                    
                                                                    if($values[8] == "Missing"){
                                                                        echo "<tr class='error-row'>";
                                                                        echo "<td class='one'>".$values[0]."</td>";
                                                                        echo "<td class='two'>".$values[1]."</td>";
                                                                        echo "<td class='three'>".$values[8]."</td>";
                                                                        echo "<td class='four'>".$values[3]."</td>";
                                                                        echo "<td class='five'>Setup#".$values[2]."</td>";
                                                                        echo "<td class='six'>".$values[5]."</td>";
                                                                        echo "<td class='seven'>".$values[4]."</td>";
                                                                        echo "<td class='eight'>".$values[7]."</td>";
                                                                        echo "</tr>";  
                                                                    }elseif($values[8] == "Added"){
                                                                        echo "<tr class='error-row'>";
                                                                        echo "<td class='one'>".$values[0]."</td>";
                                                                        echo "<td class='two'>".$values[1]."</td>";
                                                                        echo "<td class='three'>".$values[8]."</td>";
                                                                        echo "<td class='four'>".$values[3]."</td>";
                                                                        echo "<td class='five'>Setup#".$values[2]."</td>";
                                                                        echo "<td class='six'>".$values[6]."</td>";
                                                                        echo "<td class='seven'>".$values[4]."</td>";
                                                                        echo "<td class='eight'>".$values[7]."</td>";
                                                                        echo "</tr>";  
                                                                    }
                                                                }
                                                            }

                                                            if(isset($duplicate_results) && count($duplicate_results) > 0){
                                                                foreach($duplicate_results as $values){
                                                                    echo "<tr class='error-row'>";
                                                                    echo "<td>".$values['PART_NUMBER']."</td>";
                                                                    echo "<td>".$values['SEQ_NO']."</td>";
                                                                    echo "<td>".$values['REMARKS']."</td>";
                                                                    echo "<td>".$values['STEP_TYPE_CODE']."</td>";
                                                                    echo "<td>Setup#".$values['SETUP_NO']."</td>";
                                                                    echo "<td>".$values['TOOLING_PART_NO']."</td>";
                                                                    echo "<td>".$values['TOOL_TYPE']." (M:".$values['MAXCIM_COUNT']." / X:".$values['XROTS_COUNT'].")</td>";
                                                                    echo "<td></td>";
                                                                    echo "</tr>";
                                                                }
                                                            }

                                                            if(isset($opcode_results) && count($opcode_results) > 0){
                                                                foreach($opcode_results as $values){
                                                                    if($values['REMARKS'] == 'Mismatch'){
                                                                        echo "<tr class='error-row'>";
                                                                        echo "<td>".$values['PART_NUMBER']."</td>";
                                                                        echo "<td>".$values['SEQ_NO']."</td>";
                                                                        echo "<td>".$values['REMARKS']."</td>";
                                                                        echo "<td>".$values['STEP_TYPE_CODE']."</td>";
                                                                        echo "<td>Operation Code is '".$values['XROTS_OP_CODE']."' instead of '".$values['MAXCIM_OP_CODE']."'</td>";
                                                                        echo "<td></td>";
                                                                        echo "<td></td>";
                                                                        echo "<td></td>";
                                                                        echo "</tr>";
                                                                    }
                                                                }
                                                            }

                                                            if(isset($seqno_results) && count($seqno_results) > 0){
                                                                foreach($seqno_results as $values){
                                                                    if($values['REMARKS'] == 'Mismatch'){
                                                                        echo "<tr class='error-row'>";
                                                                        echo "<td>".$values['PART_NUMBER']."</td>";
                                                                        echo "<td>".$values['SEQ_NO']."</td>";
                                                                        echo "<td>".$values['REMARKS']."</td>";
                                                                        echo "<td>".$values['STEP_TYPE_CODE']."</td>";
                                                                        echo "<td>Setup#".$values['SETUP_NO']."</td>";
                                                                        echo "<td>".$values['TOOLING_PART_NO']."</td>";
                                                                        echo "<td>".$values['TOOL_TYPE']."</td>";
                                                                        echo "<td>Operation Sequence Number is '".$values['XROTS_SEQ_NO']."' instead of '".$values['MAXCIM_SEQ_NO']."'</td>";
                                                                        echo "</tr>";
                                                                    }
                                                                }
                                                            }
                                                        ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="public/js/bootstrap.min.js"></script>
        <script src="public/js/dataTables.bootstrap.min.js"></script>

        <script>
            $(document).ready( function () {
                $('#old-table').DataTable({
                    ordering: false,
                    "lengthMenu": [20, 50, 100]
                });
                $('#new-table').DataTable({
                    ordering: false,
                    "lengthMenu": [20, 50, 100]
                });
                $('#validate-table').DataTable({
                    "lengthMenu": [[-1, 20, 50],['All', 20, 50]],
                    ordering: false
                });
                $('#duplicate-table').DataTable({
                    "lengthMenu": [[-1, 20, 50],['All', 20, 50]],
                    ordering: false
                });
                $('#seqno-table').DataTable({
                    "lengthMenu": [[-1, 20, 50],['All', 20, 50]],
                    ordering: false
                });
                $('#consolidated-table').DataTable({
                    "lengthMenu": [[-1, 20, 50],['All', 20, 50]],
                    ordering: false
                });
            });
        </script>
    </body>
</html>